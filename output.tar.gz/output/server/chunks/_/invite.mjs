import { z } from 'file://D:/hamkari/node_modules/zod/index.js';

const CreateInviteSchema = z.object({
  role: z.enum(["MECHANIC", "VENDOR"]),
  phone: z.string().min(10, "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 10 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F").max(15, "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634 \u0627\u0632 15 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F").regex(/^[0-9+\-\s]+$/, "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0628\u0627\u06CC\u062F \u0641\u0642\u0637 \u0634\u0627\u0645\u0644 \u0627\u0639\u062F\u0627\u062F\u060C +\u060C - \u0648 \u0641\u0627\u0635\u0644\u0647 \u0628\u0627\u0634\u062F"),
  fullName: z.string().min(2, "\u0646\u0627\u0645 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 2 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").max(100, "\u0646\u0627\u0645 \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634 \u0627\u0632 100 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional().or(z.literal("")),
  city: z.string().min(2, "\u0634\u0647\u0631 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 2 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").max(50, "\u0634\u0647\u0631 \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634 \u0627\u0632 50 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional().or(z.literal("")),
  specialties: z.string().max(200, "\u062A\u062E\u0635\u0635\u200C\u0647\u0627 \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634 \u0627\u0632 200 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional().or(z.literal("")),
  storeName: z.string().max(100, "\u0646\u0627\u0645 \u0641\u0631\u0648\u0634\u06AF\u0627\u0647 \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634 \u0627\u0632 100 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional().or(z.literal("")),
  addressLine: z.string().max(200, "\u0622\u062F\u0631\u0633 \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634 \u0627\u0632 200 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional().or(z.literal("")),
  province: z.string().max(50, "\u0627\u0633\u062A\u0627\u0646 \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634 \u0627\u0632 50 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional().or(z.literal("")),
  postalCode: z.string().optional().or(z.literal(""))
}).refine((data) => {
  if (data.role === "VENDOR" && (!data.storeName || data.storeName.trim().length < 2)) {
    return false;
  }
  return true;
}, {
  message: "\u0646\u0627\u0645 \u0641\u0631\u0648\u0634\u06AF\u0627\u0647 \u0628\u0631\u0627\u06CC \u0646\u0642\u0634 \u0641\u0631\u0648\u0634\u06AF\u0627\u0647 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A \u0648 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 2 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F",
  path: ["storeName"]
}).refine((data) => {
  if (data.role === "VENDOR" && data.postalCode && data.postalCode.trim() !== "") {
    return /^[0-9]{10}$/.test(data.postalCode);
  }
  return true;
}, {
  message: "\u06A9\u062F \u067E\u0633\u062A\u06CC \u0628\u0627\u06CC\u062F 10 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F",
  path: ["postalCode"]
});
const InviteListQuerySchema = z.object({
  role: z.enum(["MECHANIC", "VENDOR"]).optional(),
  phone: z.string().optional(),
  status: z.enum(["ACTIVE", "USED", "EXPIRED", "CANCELED"]).optional(),
  page: z.string().regex(/^\d+$/).transform(Number).default(1),
  limit: z.string().regex(/^\d+$/).transform(Number).default(20)
});
const AcceptInviteSchema = z.object({
  token: z.string().min(12, "\u062A\u0648\u06A9\u0646 \u062F\u0639\u0648\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A").max(20, "\u062A\u0648\u06A9\u0646 \u062F\u0639\u0648\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A"),
  otpCode: z.string().length(5, "\u06A9\u062F OTP \u0628\u0627\u06CC\u062F 5 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F").regex(/^\d+$/, "\u06A9\u062F OTP \u0628\u0627\u06CC\u062F \u0641\u0642\u0637 \u0634\u0627\u0645\u0644 \u0627\u0639\u062F\u0627\u062F \u0628\u0627\u0634\u062F")
});
const ValidateInviteSchema = z.object({
  token: z.string().min(12, "\u062A\u0648\u06A9\u0646 \u062F\u0639\u0648\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A").max(20, "\u062A\u0648\u06A9\u0646 \u062F\u0639\u0648\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A")
});

export { AcceptInviteSchema as A, CreateInviteSchema as C, InviteListQuerySchema as I, ValidateInviteSchema as V };
//# sourceMappingURL=invite.mjs.map
