import { u as useRuntimeConfig, e as createError } from './nitro.mjs';
import Kavenegar from 'file://D:/hamkari/node_modules/kavenegar/kavenegar.js';

let kapi = null;
function api() {
  if (!kapi) {
    const config = useRuntimeConfig();
    const { smsProvider, kavenegar } = config;
    if (smsProvider !== "kavenegar" || !(kavenegar == null ? void 0 : kavenegar.apiKey)) {
      console.warn("[SMS] SMS provider not configured properly", {
        provider: smsProvider,
        hasKey: !!(kavenegar == null ? void 0 : kavenegar.apiKey)
      });
      throw createError({
        statusCode: 500,
        statusMessage: "SMS provider not configured"
      });
    }
    kapi = Kavenegar.KavenegarApi({ apikey: kavenegar.apiKey });
  }
  return kapi;
}
function maskPhone(p) {
  if (!p) return "unknown";
  return p.replace(/^(\d{4})\d+(\d{4})$/, "$1***$2");
}
function normalizePhone(phone) {
  if (!phone) return "";
  const cleaned = phone.replace(/\D/g, "");
  if (cleaned.startsWith("98") && cleaned.length === 12) {
    return "0" + cleaned.substring(2);
  }
  if (cleaned.startsWith("09") && cleaned.length === 11) {
    return cleaned;
  }
  if (cleaned.length === 10 && cleaned.startsWith("9")) {
    return "0" + cleaned;
  }
  return cleaned;
}
function mapKavenegarError(status, response) {
  switch (status) {
    case 400:
      return { statusCode: 400, message: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" };
    case 401:
      return { statusCode: 401, message: "\u0627\u062D\u0631\u0627\u0632 \u0647\u0648\u06CC\u062A \u0646\u0627\u0645\u0648\u0641\u0642" };
    case 403:
      return { statusCode: 403, message: "\u062F\u0633\u062A\u0631\u0633\u06CC \u063A\u06CC\u0631\u0645\u062C\u0627\u0632" };
    case 404:
      return { statusCode: 404, message: "\u0633\u0631\u0648\u06CC\u0633 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" };
    case 412:
      return { statusCode: 412, message: "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" };
    case 413:
      return { statusCode: 413, message: "\u067E\u06CC\u0627\u0645 \u062E\u06CC\u0644\u06CC \u0637\u0648\u0644\u0627\u0646\u06CC \u0627\u0633\u062A" };
    case 422:
      return { statusCode: 422, message: "\u0627\u0644\u06AF\u0648\u06CC \u067E\u06CC\u0627\u0645\u06A9 \u06CC\u0627\u0641\u062A \u0646\u0634\u062F" };
    case 429:
      return { statusCode: 429, message: "\u062A\u0639\u062F\u0627\u062F \u062F\u0631\u062E\u0648\u0627\u0633\u062A\u200C\u0647\u0627 \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 \u0627\u0633\u062A" };
    case 500:
      return { statusCode: 500, message: "\u062E\u0637\u0627\u06CC \u062F\u0627\u062E\u0644\u06CC \u0633\u0631\u0648\u0631" };
    case 502:
      return { statusCode: 502, message: "\u0633\u0631\u0648\u06CC\u0633 \u067E\u06CC\u0627\u0645\u06A9 \u0645\u0648\u0642\u062A\u0627\u064B \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0646\u06CC\u0633\u062A" };
    case 503:
      return { statusCode: 503, message: "\u0633\u0631\u0648\u06CC\u0633 \u067E\u06CC\u0627\u0645\u06A9 \u0645\u0648\u0642\u062A\u0627\u064B \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0646\u06CC\u0633\u062A" };
    default:
      return { statusCode: 502, message: "\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645\u06A9 \u0645\u0648\u0642\u062A\u0627\u064B \u0628\u0627 \u0645\u0634\u06A9\u0644 \u0645\u0648\u0627\u062C\u0647 \u0634\u062F" };
  }
}
async function sendOtpViaVerifyLookup({ phone, code, template }) {
  var _a, _b;
  const config = useRuntimeConfig();
  const devBypass = ((_a = config.kavenegar) == null ? void 0 : _a.devBypass) || false;
  const tpl = template || ((_b = config.kavenegar) == null ? void 0 : _b.templateOtp) || "otp-login";
  const normalizedPhone = normalizePhone(phone);
  if (devBypass) {
    console.info("[SMS DEV BYPASS] OTP would be sent", {
      phoneMasked: maskPhone(normalizedPhone),
      template: tpl
    });
    return { ok: true, bypass: true };
  }
  try {
    const result = await new Promise((resolve, reject) => {
      api().VerifyLookup(
        { receptor: normalizedPhone, token: code, template: tpl },
        (res, status) => {
          if (status >= 200 && status < 300) {
            resolve({ res, status });
          } else {
            reject(Object.assign(new Error("Kavenegar VerifyLookup failed"), { status, res }));
          }
        }
      );
    });
    console.info("[SMS] OTP sent via VerifyLookup", {
      phoneMasked: maskPhone(normalizedPhone),
      template: tpl,
      status: result.status
    });
    return { ok: true, provider: "kavenegar", method: "verifylookup", res: result.res };
  } catch (error) {
    const errorInfo = mapKavenegarError((error == null ? void 0 : error.status) || 500, error == null ? void 0 : error.res);
    console.error("[SMS] VerifyLookup failed", {
      phoneMasked: maskPhone(normalizedPhone),
      template: tpl,
      status: error == null ? void 0 : error.status,
      error: error == null ? void 0 : error.message
    });
    if ((error == null ? void 0 : error.res) && typeof error.res === "object") {
      console.debug("[SMS DEBUG] Kavenegar response details", {
        phoneMasked: maskPhone(normalizedPhone),
        template: tpl,
        response: error.res
      });
    }
    throw createError({
      statusCode: errorInfo.statusCode,
      statusMessage: "SMS Service Unavailable",
      message: errorInfo.message
    });
  }
}
async function sendInviteViaVerifyLookup({ phone, token, template }) {
  var _a, _b;
  const config = useRuntimeConfig();
  const devBypass = ((_a = config.kavenegar) == null ? void 0 : _a.devBypass) || false;
  const tpl = template || ((_b = config.kavenegar) == null ? void 0 : _b.templateInvite) || "invite-code";
  const normalizedPhone = normalizePhone(phone);
  if (devBypass) {
    console.info("[SMS DEV BYPASS] Invite would be sent", {
      phoneMasked: maskPhone(normalizedPhone),
      template: tpl
    });
    return { ok: true, bypass: true };
  }
  try {
    const result = await new Promise((resolve, reject) => {
      api().VerifyLookup(
        { receptor: normalizedPhone, token, template: tpl },
        (res, status) => {
          if (status >= 200 && status < 300) {
            resolve({ res, status });
          } else {
            reject(Object.assign(new Error("Kavenegar VerifyLookup failed"), { status, res }));
          }
        }
      );
    });
    console.info("[SMS] Invite sent via VerifyLookup", {
      phoneMasked: maskPhone(normalizedPhone),
      template: tpl,
      status: result.status
    });
    return { ok: true, provider: "kavenegar", method: "verifylookup", res: result.res };
  } catch (error) {
    const errorInfo = mapKavenegarError((error == null ? void 0 : error.status) || 500, error == null ? void 0 : error.res);
    console.error("[SMS] VerifyLookup failed", {
      phoneMasked: maskPhone(normalizedPhone),
      template: tpl,
      status: error == null ? void 0 : error.status,
      error: error == null ? void 0 : error.message
    });
    if ((error == null ? void 0 : error.res) && typeof error.res === "object") {
      console.debug("[SMS DEBUG] Kavenegar response details", {
        phoneMasked: maskPhone(normalizedPhone),
        template: tpl,
        response: error.res
      });
    }
    throw createError({
      statusCode: errorInfo.statusCode,
      statusMessage: "SMS Service Unavailable",
      message: errorInfo.message
    });
  }
}
async function kavenegarVerifyLookupDebug(params) {
  var _a;
  const config = useRuntimeConfig();
  const { kavenegar } = config;
  const normalized = normalizePhone(params.receptor);
  const masked = maskPhone(normalized);
  const tokenSample = params.token ? "***" : "";
  if (!(kavenegar == null ? void 0 : kavenegar.apiKey)) {
    return {
      ok: false,
      provider: "kavenegar",
      attempted: "verifylookup",
      normalized,
      masked,
      template: params.template,
      tokenSample,
      error: "Kavenegar API key not configured"
    };
  }
  const devBypass = (kavenegar == null ? void 0 : kavenegar.devBypass) || false;
  if (devBypass) {
    console.info("[SMS DEBUG] verifylookup template=" + params.template + " status=bypass phone=" + masked + " ok=true");
    return {
      ok: true,
      provider: "kavenegar",
      attempted: "verifylookup",
      normalized,
      masked,
      template: params.template,
      tokenSample,
      devBypass: true
    };
  }
  try {
    const result = await new Promise((resolve, reject) => {
      api().VerifyLookup(
        {
          receptor: normalized,
          token: params.token,
          template: params.template
        },
        (res, status) => {
          resolve({ res, status });
        }
      );
    });
    const success = result.status >= 200 && result.status < 300;
    const logLevel = success ? "info" : "warn";
    const statusStr = ((_a = result.status) == null ? void 0 : _a.toString()) || "na";
    console[logLevel]("[SMS DEBUG] verifylookup template=" + params.template + " status=" + statusStr + " phone=" + masked + " ok=" + success);
    return {
      ok: success,
      provider: "kavenegar",
      attempted: "verifylookup",
      normalized,
      masked,
      template: params.template,
      tokenSample,
      raw: result.res,
      status: result.status,
      error: success ? void 0 : `HTTP ${result.status}`
    };
  } catch (error) {
    console.warn("[SMS DEBUG] verifylookup template=" + params.template + " status=error phone=" + masked + " ok=false");
    return {
      ok: false,
      provider: "kavenegar",
      attempted: "verifylookup",
      normalized,
      masked,
      template: params.template,
      tokenSample,
      error: (error == null ? void 0 : error.message) || "Unknown error"
    };
  }
}

export { sendInviteViaVerifyLookup as a, kavenegarVerifyLookupDebug as k, sendOtpViaVerifyLookup as s };
//# sourceMappingURL=sms.mjs.map
