import { l as getCookie, e as createError } from './nitro.mjs';
import jwt from 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret";
async function requireAuth(event, allowed) {
  var _a, _b;
  let user = event.context.authUser;
  if (!user) {
    const at = getCookie(event, "at");
    if (!at) {
      throw createError({ statusCode: 401, statusMessage: "Missing token" });
    }
    try {
      const dec = jwt.verify(at, JWT_SECRET);
      const id = (_b = (_a = dec.userId) != null ? _a : dec.uid) != null ? _b : dec.sub;
      const role = dec.role;
      if (!id || !role) {
        throw new Error("bad claims");
      }
      user = { id, role, phone: dec.phone };
      event.context.authUser = user;
      event.context.authUserId = id;
    } catch (error) {
      console.error("[AUTH UTIL] Token verification failed:", error);
      throw createError({ statusCode: 401, statusMessage: "Invalid token" });
    }
  }
  if (allowed && !allowed.includes(user.role)) {
    throw createError({ statusCode: 403, statusMessage: "Forbidden" });
  }
  return user;
}
function requireRole(user, role) {
  if (user.role !== role) {
    throw createError({ statusCode: 403, statusMessage: "Forbidden" });
  }
}

export { requireRole as a, requireAuth as r };
//# sourceMappingURL=auth.mjs.map
