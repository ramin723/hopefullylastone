import jwt from 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import crypto from 'node:crypto';
import { c as createRequestLogger } from './logger.mjs';

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";
const ACCESS_TOKEN_EXPIRY = "15m";
const REFRESH_TOKEN_EXPIRY_DAYS = 30;
const generateAccessToken = (payload) => {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: ACCESS_TOKEN_EXPIRY });
};
const generateRefreshToken = () => {
  return crypto.randomBytes(32).toString("hex");
};
const hashRefreshToken = (token) => {
  return crypto.createHash("sha256").update(token).digest("hex");
};
const verifyAccessToken = (token) => {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
};
const getRefreshTokenExpiry = () => {
  const expiry = /* @__PURE__ */ new Date();
  expiry.setDate(expiry.getDate() + REFRESH_TOKEN_EXPIRY_DAYS);
  return expiry;
};
const isTokenExpired = (token) => {
  try {
    const decoded = jwt.decode(token);
    if (!decoded || !decoded.exp) return true;
    const currentTime = Math.floor(Date.now() / 1e3);
    return decoded.exp < currentTime;
  } catch {
    return true;
  }
};
const generateTokens = async (userId, event) => {
  var _a;
  const logger = createRequestLogger("token-generator");
  try {
    const { prisma } = await import('./db.mjs');
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { id: true, role: true, phone: true }
    });
    if (!user) {
      throw new Error("User not found");
    }
    const accessToken = generateAccessToken({
      userId: user.id,
      role: user.role,
      phone: user.phone
    });
    const refreshToken = generateRefreshToken();
    const refreshTokenHash = hashRefreshToken(refreshToken);
    const refreshTokenExpiry = getRefreshTokenExpiry();
    await prisma.refreshToken.create({
      data: {
        userId: user.id,
        tokenHash: refreshTokenHash,
        expiresAt: refreshTokenExpiry,
        userAgent: event.node.req.headers["user-agent"] || "unknown",
        ip: ((_a = event.node.req.connection) == null ? void 0 : _a.remoteAddress) || "unknown"
      }
    });
    logger.info("Tokens generated successfully", {
      userId: user.id,
      role: user.role
    });
    return {
      accessToken,
      refreshToken
    };
  } catch (error) {
    logger.error("Token generation failed", {
      userId,
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw error;
  }
};

export { generateRefreshToken as a, getRefreshTokenExpiry as b, generateTokens as c, generateAccessToken as g, hashRefreshToken as h, isTokenExpired as i, verifyAccessToken as v };
//# sourceMappingURL=tokens.mjs.map
