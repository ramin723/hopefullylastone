import crypto from 'node:crypto';

const buckets = /* @__PURE__ */ new Map();
function rateLimitComposite({
  key,
  windowMs = 5 * 60 * 1e3,
  max = 5
}) {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || now > b.resetAt) {
    const bucket = { count: 1, resetAt: now + windowMs };
    buckets.set(key, bucket);
    return { allowed: true, remaining: max - 1, resetAt: bucket.resetAt };
  }
  if (b.count >= max) {
    return { allowed: false, remaining: 0, resetAt: b.resetAt };
  }
  b.count += 1;
  return { allowed: true, remaining: max - b.count, resetAt: b.resetAt };
}
function getClientIP(event) {
  var _a;
  const xf = event.node.req.headers["x-forwarded-for"];
  if (typeof xf === "string" && xf.length > 0) {
    const first = (_a = xf.split(",")[0]) == null ? void 0 : _a.trim();
    if (first) return first;
  }
  return event.node.req.socket.remoteAddress || "0.0.0.0";
}
function hashPhone(phone) {
  return crypto.createHash("sha256").update((phone || "").trim()).digest("hex");
}
function maskPhone(phone) {
  const p = (phone || "").trim();
  if (p.length <= 5) return "***";
  return `${p.slice(0, 3)}***${p.slice(-2)}`;
}
function buildLoginKey(event, phone) {
  const ip = getClientIP(event);
  const ph = hashPhone(phone || "");
  return `${ip}:${ph}`;
}

export { buildLoginKey as b, getClientIP as g, hashPhone as h, maskPhone as m, rateLimitComposite as r };
//# sourceMappingURL=rateLimiter.mjs.map
