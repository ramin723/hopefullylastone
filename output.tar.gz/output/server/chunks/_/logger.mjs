import pino from 'file://D:/hamkari/node_modules/pino/pino.js';

const logger = pino({
  level: process.env.LOG_LEVEL || "info",
  transport: void 0
});
const createRequestLogger = (requestId) => {
  return logger.child({ requestId });
};

export { createRequestLogger as c, logger as l };
//# sourceMappingURL=logger.mjs.map
