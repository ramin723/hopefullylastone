import crypto from 'node:crypto';

function generateNumericCode(len = 5) {
  const min = Math.pow(10, len - 1);
  const max = Math.pow(10, len) - 1;
  const code = Math.floor(Math.random() * (max - min + 1)) + min;
  return code.toString();
}
function hashCode(code) {
  return crypto.createHash("sha256").update(code).digest("hex");
}
function isLocked(otp) {
  if (!otp.lockedUntil) return false;
  return /* @__PURE__ */ new Date() < otp.lockedUntil;
}
function normalizePhone(phone) {
  return (phone || "").trim().replace(/\s+/g, "");
}
function isExpired(otp) {
  return /* @__PURE__ */ new Date() > otp.expiresAt;
}
function isValid(otp) {
  return !isExpired(otp) && !otp.isUsed && !isLocked(otp);
}

export { isExpired as a, isValid as b, generateNumericCode as g, hashCode as h, isLocked as i, normalizePhone as n };
//# sourceMappingURL=otp.mjs.map
