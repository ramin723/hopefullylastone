import { PrismaClient } from 'file://D:/hamkari/node_modules/@prisma/client/default.js';

var _a;
const globalForPrisma = globalThis;
const prisma = (_a = globalForPrisma.prisma) != null ? _a : new PrismaClient({
  log: ["error", "warn"]
  // می‌تونیم بعداً info هم اضافه کنیم
});

export { prisma };
//# sourceMappingURL=db.mjs.map
