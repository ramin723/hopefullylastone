import { randomBytes } from 'node:crypto';

function generateOrderCode() {
  const bytes = randomBytes(9);
  const base64 = bytes.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
  return base64.slice(0, 12);
}
function isValidOrderCode(code) {
  return /^[A-Za-z0-9_-]{12}$/.test(code);
}
function generateMechanicCode() {
  const bytes = randomBytes(6);
  const base64 = bytes.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");
  return base64.slice(0, 8).toUpperCase();
}
async function generateMechanicCodeUnique(prisma2) {
  let attempts = 0;
  const maxAttempts = 10;
  while (attempts < maxAttempts) {
    const code = generateMechanicCode();
    const existing = await prisma2.mechanic.findUnique({
      where: { code }
    });
    if (!existing) {
      return code;
    }
    attempts++;
  }
  const timestamp = Date.now().toString(36).toUpperCase();
  return `M${timestamp.slice(-8)}`;
}

export { generateMechanicCodeUnique as a, generateOrderCode as b, generateMechanicCode as g, isValidOrderCode as i };
//# sourceMappingURL=ids.mjs.map
