function decimalToNumber(value) {
  if (!value) return 0;
  if (typeof value === "object" && "toNumber" in value) {
    return value.toNumber();
  }
  return Number(value);
}

export { decimalToNumber as d };
//# sourceMappingURL=decimal.mjs.map
