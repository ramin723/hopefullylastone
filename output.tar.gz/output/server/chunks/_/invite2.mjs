import crypto from 'node:crypto';
import { n as normalizePhone } from './otp.mjs';
import { m as maskPhone } from './rateLimiter.mjs';
import { a as sendInviteViaVerifyLookup } from './sms.mjs';

function generateInviteToken(length = 16) {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
function hashToken(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}
async function sendInviteSms(phone, token, role, fullName) {
  const normalizedPhone = normalizePhone(phone);
  try {
    const result = await sendInviteViaVerifyLookup({
      phone: normalizedPhone,
      token,
      template: "invite-code"
    });
    return {
      ok: true,
      sent: true
    };
  } catch (error) {
    console.error("[SMS] Invite send failed", {
      phoneMasked: maskPhone(normalizedPhone),
      error: error.message
    });
    return {
      ok: false,
      sent: false,
      error: error.message
    };
  }
}
function isInviteExpired(expiresAt) {
  return /* @__PURE__ */ new Date() > expiresAt;
}
function isInviteUsed(usedAt) {
  return usedAt !== null;
}
function isInviteValid(invite) {
  return !isInviteExpired(invite.expiresAt) && !isInviteUsed(invite.usedAt);
}
function inviteActiveWhere(phone, role) {
  return {
    phone: normalizePhone(phone),
    role,
    usedAt: null,
    canceledAt: null,
    expiresAt: { gt: /* @__PURE__ */ new Date() }
  };
}
function getInviteStatus(invite) {
  if (invite.usedAt) {
    return "USED";
  }
  if (invite.canceledAt) {
    return "CANCELED";
  }
  if (isInviteExpired(invite.expiresAt)) {
    return "EXPIRED";
  }
  return "ACTIVE";
}

export { generateInviteToken as a, isInviteValid as b, getInviteStatus as g, hashToken as h, inviteActiveWhere as i, sendInviteSms as s };
//# sourceMappingURL=invite2.mjs.map
