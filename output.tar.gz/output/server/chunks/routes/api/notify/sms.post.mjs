import { c as defineEventHandler, e as createError, r as readBody } from '../../../_/nitro.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../_/rateLimiter.mjs';
import { l as logger } from '../../../_/logger.mjs';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const SmsRequestSchema = z.object({
  phone: z.string().min(10).max(15),
  text: z.string().min(1).max(500)
});
const sms_post = defineEventHandler(async (event) => {
  const requestId = crypto.randomUUID();
  try {
    const auth = await requireAuth(event, ["MECHANIC", "ADMIN", "VENDOR"]);
    const ip = getClientIP(event);
    const rateKey = `sms.send:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 5 * 60 * 1e3,
      // 5 minutes
      max: 10
    });
    if (!rateLimit.allowed) {
      logger.warn({
        requestId,
        userId: auth.id,
        userRole: auth.role,
        ip,
        remaining: rateLimit.remaining,
        resetAt: rateLimit.resetAt
      }, "[SMS API] Rate limit exceeded");
      throw createError({
        statusCode: 429,
        statusMessage: "Too many SMS requests"
      });
    }
    const body = await readBody(event);
    const validation = SmsRequestSchema.safeParse(body);
    if (!validation.success) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid request data: " + validation.error.issues.map((i) => i.message).join(", ")
      });
    }
    const { phone, text } = validation.data;
    const smsProvider = process.env.SMS_PROVIDER;
    if (!smsProvider) {
      logger.info({
        requestId,
        userId: auth.id,
        userRole: auth.role,
        phone: `***${phone.slice(-4)}`,
        textLength: text.length,
        message: "SMS provider not configured - dev mode stub"
      }, "[SMS API] SMS notification requested (dev stub)");
      return {
        ok: true,
        dev: true,
        message: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A SMS \u062B\u0628\u062A \u0634\u062F (\u062D\u0627\u0644\u062A \u062A\u0648\u0633\u0639\u0647)",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
    logger.info({
      requestId,
      userId: auth.id,
      userRole: auth.role,
      phone: `***${phone.slice(-4)}`,
      textLength: text.length,
      provider: smsProvider,
      message: "Production SMS integration not yet implemented"
    }, "[SMS API] SMS notification requested (production)");
    return {
      ok: true,
      message: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A SMS \u062B\u0628\u062A \u0634\u062F (\u062F\u0631 \u062D\u0627\u0644 \u062A\u0648\u0633\u0639\u0647)",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
  } catch (error) {
    if (error.statusCode === 400) {
      logger.warn({
        requestId,
        message: "Bad request - Invalid SMS data"
      }, "[SMS API] Bad request");
    } else if (error.statusCode === 429) {
      logger.warn({
        requestId,
        message: "Rate limit exceeded"
      }, "[SMS API] Rate limit exceeded");
    } else if (error.statusCode) {
      logger.error({
        requestId,
        statusCode: error.statusCode,
        message: error.statusMessage
      }, "[SMS API] Client error");
    } else {
      logger.error({
        requestId,
        err: error
      }, "[SMS API] Internal server error");
    }
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "\u062E\u0637\u0627\u06CC \u062F\u0627\u062E\u0644\u06CC \u062F\u0631 \u0627\u0631\u0633\u0627\u0644 SMS"
    });
  }
});

export { sms_post as default };
//# sourceMappingURL=sms.post.mjs.map
