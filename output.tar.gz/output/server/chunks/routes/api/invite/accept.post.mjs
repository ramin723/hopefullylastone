import { c as defineEventHandler, r as readBody, e as createError, h as appendResponseHeader, i as setCookie } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { c as createRequestLogger } from '../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { g as getClientIP, r as rateLimitComposite, m as maskPhone } from '../../../_/rateLimiter.mjs';
import { A as AcceptInviteSchema } from '../../../_/invite.mjs';
import { h as hashToken, b as isInviteValid } from '../../../_/invite2.mjs';
import { n as normalizePhone, h as hashCode, b as isValid } from '../../../_/otp.mjs';
import { c as generateTokens } from '../../../_/tokens.mjs';
import { a as generateMechanicCodeUnique } from '../../../_/ids.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';
import 'file://D:/hamkari/node_modules/zod/index.js';
import '../../../_/sms.mjs';
import 'file://D:/hamkari/node_modules/kavenegar/kavenegar.js';

const accept_post = defineEventHandler(async (event) => {
  var _a;
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Invite acceptance started");
  const body = await readBody(event);
  const validation = AcceptInviteSchema.safeParse(body);
  if (!validation.success) {
    logger.error("Invite acceptance validation failed", {
      requestId,
      errors: validation.error.issues.map((e) => e.message)
    });
    throw createError({
      statusCode: 400,
      statusMessage: ((_a = validation.error.issues[0]) == null ? void 0 : _a.message) || "Invalid input"
    });
  }
  const { token, otpCode } = validation.data;
  const ip = getClientIP(event);
  const key = `${ip}:invite-accept`;
  const { allowed, remaining, resetAt } = rateLimitComposite({
    key,
    windowMs: 10 * 60 * 1e3,
    // 10 minutes
    max: 10
    // 10 requests per 10 minutes
  });
  if (!allowed) {
    const retryAfterSec = Math.max(1, Math.ceil((resetAt - Date.now()) / 1e3));
    appendResponseHeader(event, "Retry-After", retryAfterSec);
    logger.warn("Invite acceptance rate-limited", {
      requestId,
      remaining,
      resetAt
    });
    throw createError({
      statusCode: 429,
      statusMessage: "Too Many Requests",
      message: "Too many acceptance requests. Please try again later."
    });
  }
  logger.info("Invite acceptance allowed", {
    requestId,
    remaining,
    resetAt
  });
  try {
    const tokenHash = hashToken(token);
    const invite = await prisma.invite.findFirst({
      where: { codeHash: tokenHash },
      include: {
        createdByUser: {
          select: {
            id: true,
            fullName: true
          }
        }
      }
    });
    if (!invite) {
      logger.warn("Invite not found", { requestId });
      throw createError({
        statusCode: 404,
        statusMessage: "Invite not found"
      });
    }
    if (!isInviteValid(invite)) {
      const reason = invite.usedAt ? "used" : "expired";
      logger.warn("Invite is invalid", {
        requestId,
        inviteId: invite.id,
        reason
      });
      throw createError({
        statusCode: 410,
        statusMessage: "Invite is no longer valid",
        message: reason === "used" ? "\u0627\u06CC\u0646 \u062F\u0639\u0648\u062A \u0642\u0628\u0644\u0627\u064B \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0634\u062F\u0647 \u0627\u0633\u062A" : "\u0627\u06CC\u0646 \u062F\u0639\u0648\u062A \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A"
      });
    }
    const normalizedPhone = normalizePhone(invite.phone);
    const otpCodeHash = hashCode(otpCode);
    const otpRecord = await prisma.otpCode.findFirst({
      where: {
        phone: normalizedPhone,
        codeHash: otpCodeHash,
        purpose: "login",
        isUsed: false,
        expiresAt: { gt: /* @__PURE__ */ new Date() }
      },
      orderBy: { createdAt: "desc" }
    });
    if (!otpRecord || !isValid(otpRecord)) {
      logger.warn("Invalid OTP for invite acceptance", {
        requestId,
        inviteId: invite.id,
        phone: maskPhone(normalizedPhone)
      });
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid OTP",
        message: "\u06A9\u062F \u062A\u0623\u06CC\u06CC\u062F \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A"
      });
    }
    const result = await prisma.$transaction(async (tx) => {
      var _a2, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
      await tx.otpCode.update({
        where: { id: otpRecord.id },
        data: { isUsed: true }
      });
      let user = await tx.user.findUnique({
        where: { phone: normalizedPhone },
        include: {
          Mechanic: invite.role === "MECHANIC",
          Vendor: invite.role === "VENDOR"
        }
      });
      let userCreated = false;
      let roleEntityCreated = false;
      let qrGenerated = false;
      if (user) {
        if (user.role !== invite.role) {
          logger.warn("User exists with different role", {
            requestId,
            userId: user.id,
            userRole: user.role,
            inviteRole: invite.role
          });
          throw createError({
            statusCode: 400,
            statusMessage: "User role mismatch",
            message: "\u06A9\u0627\u0631\u0628\u0631\u06CC \u0628\u0627 \u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0628\u0627 \u0646\u0642\u0634 \u0645\u062A\u0641\u0627\u0648\u062A \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F"
          });
        }
        if (user.status !== "ACTIVE") {
          user = await tx.user.update({
            where: { id: user.id },
            data: { status: "ACTIVE" },
            include: {
              Mechanic: invite.role === "MECHANIC",
              Vendor: invite.role === "VENDOR"
            }
          });
        }
        if (invite.meta && ((_a2 = invite.meta) == null ? void 0 : _a2.fullName)) {
          user = await tx.user.update({
            where: { id: user.id },
            data: {
              fullName: invite.meta.fullName
            },
            include: {
              Mechanic: invite.role === "MECHANIC",
              Vendor: invite.role === "VENDOR"
            }
          });
        }
        const hasPassword = user.passwordHash && user.passwordHash.length > 0;
        console.debug("[INVITE ACCEPT] User exists check", {
          userId: user.id,
          hasPassword,
          currentMustChangePassword: user.mustChangePassword,
          passwordHashLength: ((_b = user.passwordHash) == null ? void 0 : _b.length) || 0
        });
        if (!hasPassword) {
          user = await tx.user.update({
            where: { id: user.id },
            data: {
              mustChangePassword: true
            },
            include: {
              Mechanic: invite.role === "MECHANIC",
              Vendor: invite.role === "VENDOR"
            }
          });
          console.debug("[INVITE ACCEPT] Set mustChangePassword to true", {
            userId: user.id,
            newMustChangePassword: user.mustChangePassword
          });
        }
      } else {
        const userData = {
          fullName: ((_c = invite.meta) == null ? void 0 : _c.fullName) || "\u06A9\u0627\u0631\u0628\u0631 \u062C\u062F\u06CC\u062F",
          phone: normalizedPhone,
          passwordHash: "",
          // Will be set when user sets password
          mustChangePassword: true,
          // User must set password on first login
          role: invite.role,
          status: "ACTIVE"
        };
        user = await tx.user.create({
          data: userData,
          include: {
            Mechanic: invite.role === "MECHANIC",
            Vendor: invite.role === "VENDOR"
          }
        });
        userCreated = true;
      }
      if (invite.role === "MECHANIC") {
        let mechanic = user.Mechanic;
        if (!mechanic) {
          const mechanicCode = await generateMechanicCodeUnique(tx);
          const mechanicData = {
            userId: user.id,
            code: mechanicCode,
            qrActive: true,
            city: (_d = invite.meta) == null ? void 0 : _d.city,
            specialties: (_e = invite.meta) == null ? void 0 : _e.specialties
          };
          mechanic = await tx.mechanic.create({
            data: mechanicData
          });
          roleEntityCreated = true;
          qrGenerated = true;
        } else {
          const updateData = {};
          if (!mechanic.code) {
            updateData.code = await generateMechanicCodeUnique(tx);
            qrGenerated = true;
          }
          if (!mechanic.qrActive) {
            updateData.qrActive = true;
          }
          if (Object.keys(updateData).length > 0) {
            mechanic = await tx.mechanic.update({
              where: { id: mechanic.id },
              data: updateData
            });
          }
        }
      } else if (invite.role === "VENDOR") {
        let vendor = user.Vendor;
        if (!vendor) {
          const vendorData = {
            userId: user.id,
            storeName: ((_f = invite.meta) == null ? void 0 : _f.storeName) || "\u0641\u0631\u0648\u0634\u06AF\u0627\u0647 \u062C\u062F\u06CC\u062F",
            city: (_g = invite.meta) == null ? void 0 : _g.city,
            addressLine: (_h = invite.meta) == null ? void 0 : _h.addressLine,
            province: (_i = invite.meta) == null ? void 0 : _i.province,
            postalCode: (_j = invite.meta) == null ? void 0 : _j.postalCode,
            isActive: true
          };
          vendor = await tx.vendor.create({
            data: vendorData
          });
          roleEntityCreated = true;
        } else {
          const updateData = {};
          if (invite.meta && ((_k = invite.meta) == null ? void 0 : _k.storeName)) {
            updateData.storeName = invite.meta.storeName;
          }
          if (invite.meta && ((_l = invite.meta) == null ? void 0 : _l.city)) {
            updateData.city = invite.meta.city;
          }
          if (Object.keys(updateData).length > 0) {
            vendor = await tx.vendor.update({
              where: { id: vendor.id },
              data: updateData
            });
          }
        }
      }
      await tx.invite.update({
        where: { id: invite.id },
        data: { usedAt: /* @__PURE__ */ new Date() }
      });
      return {
        user,
        userCreated,
        roleEntityCreated,
        qrGenerated
      };
    });
    const tokens = await generateTokens(result.user.id, event);
    const isProd = true;
    setCookie(event, "at", tokens.accessToken, {
      httpOnly: true,
      sameSite: "lax",
      secure: isProd,
      // ← DEV: false  |  PROD: true
      path: "/",
      maxAge: 60 * 15
      // 15m
    });
    setCookie(event, "rt", tokens.refreshToken, {
      httpOnly: true,
      sameSite: "lax",
      secure: isProd,
      // ← DEV: false  |  PROD: true
      path: "/",
      maxAge: 60 * 60 * 24 * 30
      // 30d
    });
    if (!isProd) ;
    logger.info("Invite accepted successfully", {
      requestId,
      inviteId: invite.id,
      userId: result.user.id,
      role: invite.role,
      phone: maskPhone(normalizedPhone),
      userCreated: result.userCreated,
      roleEntityCreated: result.roleEntityCreated,
      qrGenerated: result.qrGenerated,
      mustChangePassword: result.user.mustChangePassword
    });
    console.info("[INVITE ACCEPT] User invite accepted", {
      userId: result.user.id,
      role: invite.role,
      mustChangePassword: result.user.mustChangePassword,
      hasPassword: result.user.passwordHash && result.user.passwordHash.length > 0,
      userCreated: result.userCreated,
      expectedRedirect: result.user.mustChangePassword ? "/onboarding/set-password" : invite.role === "MECHANIC" ? "/mechanic" : "/vendor",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    });
    return {
      ok: true,
      user: {
        id: result.user.id,
        role: result.user.role,
        fullName: result.user.fullName,
        phone: result.user.phone
      },
      created: {
        user: result.userCreated,
        roleEntity: result.roleEntityCreated,
        qrGenerated: result.qrGenerated
      },
      redirect: invite.role === "MECHANIC" ? "/mechanic" : "/vendor",
      tokens
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error("Invite acceptance failed", {
      requestId,
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      message: "Failed to accept invite"
    });
  }
});

export { accept_post as default };
//# sourceMappingURL=accept.post.mjs.map
