import { c as defineEventHandler, f as getRouterParam, e as createError, h as appendResponseHeader } from '../../../../_/nitro.mjs';
import { prisma } from '../../../../_/db.mjs';
import { c as createRequestLogger } from '../../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { g as getClientIP, r as rateLimitComposite, m as maskPhone } from '../../../../_/rateLimiter.mjs';
import { V as ValidateInviteSchema } from '../../../../_/invite.mjs';
import { h as hashToken, b as isInviteValid } from '../../../../_/invite2.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';
import 'file://D:/hamkari/node_modules/zod/index.js';
import '../../../../_/otp.mjs';
import '../../../../_/sms.mjs';
import 'file://D:/hamkari/node_modules/kavenegar/kavenegar.js';

const _token__get = defineEventHandler(async (event) => {
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Invite validation started");
  const token = getRouterParam(event, "token");
  const validation = ValidateInviteSchema.safeParse({ token });
  if (!validation.success) {
    logger.error("Invite validation failed - invalid token format", {
      requestId,
      errors: validation.error.issues.map((e) => e.message)
    });
    throw createError({
      statusCode: 400,
      statusMessage: "Invalid invite token format"
    });
  }
  const ip = getClientIP(event);
  const key = `${ip}:invite-validate`;
  const { allowed, remaining, resetAt } = rateLimitComposite({
    key,
    windowMs: 5 * 60 * 1e3,
    // 5 minutes
    max: 60
    // 60 requests per 5 minutes
  });
  if (!allowed) {
    const retryAfterSec = Math.max(1, Math.ceil((resetAt - Date.now()) / 1e3));
    appendResponseHeader(event, "Retry-After", retryAfterSec);
    logger.warn("Invite validation rate-limited", {
      requestId,
      remaining,
      resetAt
    });
    throw createError({
      statusCode: 429,
      statusMessage: "Too Many Requests",
      message: "Too many validation requests. Please try again later."
    });
  }
  logger.info("Invite validation allowed", {
    requestId,
    remaining,
    resetAt
  });
  try {
    const tokenHash = hashToken(token);
    const invite = await prisma.invite.findFirst({
      where: { codeHash: tokenHash },
      include: {
        createdByUser: {
          select: {
            id: true,
            fullName: true
          }
        }
      }
    });
    if (!invite) {
      logger.warn("Invite not found", { requestId });
      throw createError({
        statusCode: 404,
        statusMessage: "Invite not found"
      });
    }
    if (!isInviteValid(invite)) {
      const reason = invite.usedAt ? "used" : "expired";
      logger.warn("Invite is invalid", {
        requestId,
        inviteId: invite.id,
        reason,
        expiresAt: invite.expiresAt,
        usedAt: invite.usedAt
      });
      throw createError({
        statusCode: 410,
        statusMessage: "Invite is no longer valid",
        message: reason === "used" ? "\u0627\u06CC\u0646 \u062F\u0639\u0648\u062A \u0642\u0628\u0644\u0627\u064B \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0634\u062F\u0647 \u0627\u0633\u062A" : "\u0627\u06CC\u0646 \u062F\u0639\u0648\u062A \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A"
      });
    }
    logger.info("Invite validation successful", {
      requestId,
      inviteId: invite.id,
      role: invite.role,
      phone: maskPhone(invite.phone),
      expiresAt: invite.expiresAt
    });
    return {
      ok: true,
      data: {
        role: invite.role,
        phone: invite.phone,
        // Return actual phone for OTP requests
        phoneMasked: maskPhone(invite.phone),
        // Return masked phone for display
        meta: invite.meta,
        expiresAt: invite.expiresAt,
        createdBy: invite.createdByUser.fullName
      }
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error("Invite validation failed", {
      requestId,
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      message: "Failed to validate invite"
    });
  }
});

export { _token__get as default };
//# sourceMappingURL=_token_.get.mjs.map
