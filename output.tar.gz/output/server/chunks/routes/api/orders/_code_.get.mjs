import { c as defineEventHandler, m as getMethod, f as getRouterParam, e as createError } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../_/rateLimiter.mjs';
import { l as logger } from '../../../_/logger.mjs';
import { i as isValidOrderCode } from '../../../_/ids.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const _code__get = defineEventHandler(async (event) => {
  if (getMethod(event) === "HEAD") {
    try {
      const auth = await requireAuth(event, ["VENDOR"]);
      const code = getRouterParam(event, "code");
      if (!code || !isValidOrderCode(code)) {
        throw createError({ statusCode: 400, statusMessage: "Invalid order code format" });
      }
      const order = await prisma.order.findUnique({
        where: { code },
        select: { id: true, status: true }
      });
      if (!order) {
        throw createError({ statusCode: 404, statusMessage: "Order not found" });
      }
      if (order.status !== "PENDING") {
        throw createError({ statusCode: 409, statusMessage: "Order already consumed or invalid" });
      }
      return { ok: true };
    } catch (error) {
      if (error.statusCode) {
        throw error;
      }
      throw createError({ statusCode: 500, statusMessage: "Internal server error" });
    }
  }
  try {
    const auth = await requireAuth(event, ["VENDOR"]);
    const ip = getClientIP(event);
    const rateKey = `orders.retrieve:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 5 * 60 * 1e3,
      // 5 minutes
      max: 60
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many order retrieval requests"
      });
    }
    const code = getRouterParam(event, "code");
    if (!code || !isValidOrderCode(code)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid order code format"
      });
    }
    const order = await prisma.order.findUnique({
      where: { code },
      include: {
        mechanic: {
          select: {
            id: true,
            code: true,
            user: {
              select: {
                fullName: true
              }
            }
          }
        },
        items: {
          select: {
            title: true,
            quantity: true,
            note: true
          }
        }
      }
    });
    if (!order) {
      logger.warn({ code, vendorId: auth.id }, "[ORDERS API] Order not found");
      throw createError({
        statusCode: 404,
        statusMessage: "Order not found"
      });
    }
    if (order.status !== "PENDING") {
      logger.warn({
        orderId: order.id,
        code,
        status: order.status,
        vendorId: auth.id
      }, "[ORDERS API] Order already consumed or invalid");
      throw createError({
        statusCode: 409,
        statusMessage: "Order already consumed or invalid"
      });
    }
    logger.info({
      orderId: order.id,
      code,
      vendorId: auth.id,
      customerPhone: `***${order.customerPhone.slice(-4)}`
    }, "[ORDERS API] Order retrieved for POS");
    return {
      ok: true,
      order: {
        id: order.id,
        code: order.code,
        mechanic: {
          id: order.mechanic.id,
          code: order.mechanic.code,
          name: order.mechanic.user.fullName
        },
        customerPhone: order.customerPhone,
        note: order.note,
        items: order.items,
        createdAt: order.createdAt
      }
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error({ err: error }, "[ORDERS API] Error retrieving order");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while retrieving order"
    });
  }
});

export { _code__get as default };
//# sourceMappingURL=_code_.get.mjs.map
