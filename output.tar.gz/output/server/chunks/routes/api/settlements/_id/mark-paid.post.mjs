import { c as defineEventHandler, f as getRouterParam, e as createError } from '../../../../_/nitro.mjs';
import { prisma } from '../../../../_/db.mjs';
import { r as requireAuth } from '../../../../_/auth.mjs';
import { l as logger } from '../../../../_/logger.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const markPaid_post = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const id = Number(getRouterParam(event, "id"));
    if (!id || isNaN(id)) {
      throw createError({ statusCode: 400, statusMessage: "Invalid settlement ID" });
    }
    const existingSettlement = await prisma.settlement.findUnique({
      where: { id },
      select: { id: true, status: true, vendorId: true }
    });
    if (!existingSettlement) {
      throw createError({ statusCode: 404, statusMessage: "Settlement not found" });
    }
    if (existingSettlement.status === "PAID") {
      throw createError({ statusCode: 400, statusMessage: "Settlement is already marked as paid" });
    }
    const updatedSettlement = await prisma.$transaction(async (tx) => {
      const updated = await tx.settlement.update({
        where: { id },
        data: { status: "PAID", paidAt: /* @__PURE__ */ new Date() }
      });
      const txIds = (await tx.settlementItem.findMany({
        where: { settlementId: id },
        select: { transactionId: true }
      })).map((i) => i.transactionId);
      if (txIds.length) {
        await tx.transaction.updateMany({
          where: { id: { in: txIds } },
          data: { status: "SETTLED" }
        });
      }
      return updated;
    });
    logger.info({ id, adminId: auth.id }, "[MARK PAID API] Settlement marked as paid");
    return {
      ok: true,
      id: updatedSettlement.id,
      status: updatedSettlement.status,
      paidAt: updatedSettlement.paidAt
    };
  } catch (error) {
    logger.error({ err: error, id: getRouterParam(event, "id") }, "Error marking settlement as paid");
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while marking settlement as paid"
    });
  }
});

export { markPaid_post as default };
//# sourceMappingURL=mark-paid.post.mjs.map
