import { c as defineEventHandler, f as getRouterParam, e as createError } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import { d as decimalToNumber } from '../../../_/decimal.mjs';
import { l as logger } from '../../../_/logger.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const _id__get = defineEventHandler(async (event) => {
  var _a;
  try {
    const auth = await requireAuth(event, ["ADMIN", "VENDOR", "MECHANIC"]);
    const id = Number(getRouterParam(event, "id"));
    if (!id || isNaN(id)) {
      throw createError({ statusCode: 400, statusMessage: "Invalid settlement ID" });
    }
    const settlement = await prisma.settlement.findUnique({
      where: { id },
      include: {
        vendor: true,
        items: {
          include: {
            transaction: {
              include: {
                commission: true,
                mechanic: {
                  include: {
                    user: true
                  }
                }
              }
            }
          }
        }
      }
    });
    if (!settlement) {
      throw createError({ statusCode: 404, statusMessage: "Settlement not found" });
    }
    if (auth.role === "VENDOR") {
      const vendor = await prisma.vendor.findUnique({
        where: { userId: auth.id },
        select: { id: true }
      });
      if (!vendor || vendor.id !== settlement.vendorId) {
        throw createError({ statusCode: 403, statusMessage: "Access denied: You can only view your own settlements" });
      }
    }
    if (auth.role === "MECHANIC") {
      const mechanic = await prisma.mechanic.findUnique({
        where: { userId: auth.id },
        select: { id: true }
      });
      if (!mechanic) {
        throw createError({ statusCode: 403, statusMessage: "Mechanic profile not found" });
      }
      const hasAccess = settlement.items.some(
        (item) => item.transaction.mechanicId === mechanic.id
      );
      if (!hasAccess) {
        throw createError({ statusCode: 403, statusMessage: "Access denied: This settlement does not contain your transactions" });
      }
    }
    return {
      id: settlement.id,
      vendor: {
        id: settlement.vendorId,
        name: settlement.vendor.storeName,
        city: settlement.vendor.city
      },
      periodFrom: settlement.periodFrom,
      periodTo: settlement.periodTo,
      totals: {
        eligible: decimalToNumber(settlement.totalAmountEligible),
        mechanic: decimalToNumber(settlement.totalMechanicAmount),
        platform: decimalToNumber(settlement.totalPlatformAmount)
      },
      status: settlement.status,
      createdAt: settlement.createdAt,
      paidAt: (_a = settlement.paidAt) != null ? _a : null,
      items: settlement.items.map((item) => ({
        txId: item.transactionId,
        createdAt: item.transaction.createdAt,
        customerPhone: item.transaction.customerPhone,
        note: item.transaction.note,
        mechanic: {
          id: item.transaction.mechanicId,
          name: item.transaction.mechanic.user.fullName,
          code: item.transaction.mechanic.code
        },
        amounts: {
          total: decimalToNumber(item.transaction.amountTotal),
          eligible: decimalToNumber(item.transaction.amountEligible),
          mechanic: decimalToNumber(item.mechanicAmount),
          platform: decimalToNumber(item.platformAmount)
        },
        commission: item.transaction.commission ? {
          rateMechanic: item.transaction.commission.rateMechanic,
          ratePlatform: item.transaction.commission.ratePlatform
        } : null
      }))
    };
  } catch (error) {
    const sid = Number(getRouterParam(event, "id"));
    logger.error({ err: error, id: sid }, "Error retrieving settlement details");
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while retrieving settlement details"
    });
  }
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
