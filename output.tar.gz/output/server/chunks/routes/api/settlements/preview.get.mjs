import { c as defineEventHandler, g as getQuery, e as createError } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import { d as decimalToNumber } from '../../../_/decimal.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';

const preview_get = defineEventHandler(async (event) => {
  await requireAuth(event, ["ADMIN"]);
  const q = getQuery(event);
  const vendorId = Number(q.vendorId);
  if (!vendorId || isNaN(vendorId)) {
    throw createError({ statusCode: 400, statusMessage: "vendorId \u0627\u0644\u0632\u0627\u0645\u06CC \u0648 \u0628\u0627\u06CC\u062F \u0639\u062F\u062F\u06CC \u0628\u0627\u0634\u062F" });
  }
  const mechanicId = q.mechanicId ? Number(q.mechanicId) : void 0;
  if (q.mechanicId && (isNaN(Number(q.mechanicId)) || Number(q.mechanicId) <= 0)) {
    throw createError({ statusCode: 400, statusMessage: "mechanicId \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" });
  }
  const from = typeof q.from === "string" ? q.from : "";
  const to = typeof q.to === "string" ? q.to : "";
  if (!from || !to) {
    throw createError({ statusCode: 400, statusMessage: "from \u0648 to \u0627\u0644\u0632\u0627\u0645\u06CC \u0647\u0633\u062A\u0646\u062F" });
  }
  const page = q.page ? Math.max(1, Number(q.page)) : 1;
  const pageSize = q.pageSize ? Math.min(100, Math.max(1, Number(q.pageSize))) : 20;
  if (isNaN(page) || isNaN(pageSize)) {
    throw createError({ statusCode: 400, statusMessage: "page \u06CC\u0627 pageSize \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" });
  }
  const fromDate = new Date(from);
  const toDate = new Date(to);
  if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime())) {
    throw createError({ statusCode: 400, statusMessage: "\u0641\u0631\u0645\u062A \u062A\u0627\u0631\u06CC\u062E \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" });
  }
  fromDate.setHours(0, 0, 0, 0);
  toDate.setHours(23, 59, 59, 999);
  const excludedIds = (await prisma.settlementItem.findMany({ select: { transactionId: true } })).map((i) => i.transactionId);
  const where = {
    vendorId,
    status: "PENDING",
    createdAt: { gte: fromDate, lte: toDate },
    id: { notIn: excludedIds },
    ...mechanicId ? { mechanicId } : {}
  };
  const allForTotals = await prisma.transaction.findMany({
    where,
    select: {
      amountEligible: true,
      commission: { select: { mechanicAmount: true, platformAmount: true } }
    }
  });
  const totalsEligible = allForTotals.reduce((sum, t) => sum + decimalToNumber(t.amountEligible), 0);
  const totalsMechanic = allForTotals.reduce((sum, t) => {
    var _a;
    return sum + decimalToNumber((_a = t.commission) == null ? void 0 : _a.mechanicAmount);
  }, 0);
  const totalsPlatform = allForTotals.reduce((sum, t) => {
    var _a;
    return sum + decimalToNumber((_a = t.commission) == null ? void 0 : _a.platformAmount);
  }, 0);
  const count = allForTotals.length;
  const itemsPage = await prisma.transaction.findMany({
    where,
    orderBy: { createdAt: "desc" },
    include: { commission: true, mechanic: { include: { user: true } } },
    skip: (page - 1) * pageSize,
    take: pageSize
  });
  const items = itemsPage.map((t) => {
    var _a, _b, _c;
    return {
      id: t.id,
      createdAt: t.createdAt,
      customerPhone: t.customerPhone,
      mechanic: { id: t.mechanicId, name: t.mechanic.user.fullName, code: t.mechanic.code },
      amounts: {
        total: Number(t.amountTotal),
        eligible: Number(t.amountEligible),
        mechanic: decimalToNumber((_a = t.commission) == null ? void 0 : _a.mechanicAmount),
        platform: decimalToNumber((_b = t.commission) == null ? void 0 : _b.platformAmount)
      },
      note: (_c = t.note) != null ? _c : null
    };
  });
  return {
    items,
    totals: {
      eligible: totalsEligible,
      mechanic: totalsMechanic,
      platform: totalsPlatform
    },
    count
  };
});

export { preview_get as default };
//# sourceMappingURL=preview.get.mjs.map
