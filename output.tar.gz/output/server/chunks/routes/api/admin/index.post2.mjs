import { c as defineEventHandler, e as createError, r as readBody } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite, m as maskPhone } from '../../../_/rateLimiter.mjs';
import { g as generateMechanicCode } from '../../../_/ids.mjs';
import { l as logger } from '../../../_/logger.mjs';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const CreateMechanicSchema = z.object({
  fullName: z.string().min(3, "\u0646\u0627\u0645 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 3 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F"),
  phone: z.string().min(10, "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 10 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F").max(15, "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634 \u0627\u0632 15 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F"),
  note: z.string().optional(),
  assignQrNow: z.boolean().default(false)
});
const index_post = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const ip = getClientIP(event);
    const rateKey = `admin.mechanics.create:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 5 * 60 * 1e3,
      // 5 minutes
      max: 20
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many requests"
      });
    }
    const body = await readBody(event);
    const validation = CreateMechanicSchema.safeParse(body);
    if (!validation.success) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid request data: " + validation.error.issues.map((i) => i.message).join(", ")
      });
    }
    const { fullName, phone, note, assignQrNow } = validation.data;
    const existingUser = await prisma.user.findUnique({
      where: { phone },
      select: { id: true, role: true, fullName: true }
    });
    let userCreated = false;
    let userId;
    if (existingUser) {
      if (existingUser.role === "VENDOR") {
        throw createError({
          statusCode: 409,
          statusMessage: "\u06A9\u0627\u0631\u0628\u0631 \u0628\u0627 \u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0642\u0628\u0644\u0627\u064B \u0628\u0647 \u0639\u0646\u0648\u0627\u0646 \u0641\u0631\u0648\u0634\u06AF\u0627\u0647 \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A"
        });
      }
      if (existingUser.role === "ADMIN") {
        throw createError({
          statusCode: 409,
          statusMessage: "\u06A9\u0627\u0631\u0628\u0631 \u0628\u0627 \u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0642\u0628\u0644\u0627\u064B \u0628\u0647 \u0639\u0646\u0648\u0627\u0646 \u0627\u062F\u0645\u06CC\u0646 \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A"
        });
      }
      userId = existingUser.id;
      if (existingUser.role !== "MECHANIC") {
        await prisma.user.update({
          where: { id: userId },
          data: { role: "MECHANIC" }
        });
      }
    } else {
      const newUser = await prisma.user.create({
        data: {
          fullName,
          phone,
          passwordHash: "",
          // No password set initially
          mustChangePassword: true,
          // User must set password on first login
          role: "MECHANIC"
        },
        select: { id: true }
      });
      userId = newUser.id;
      userCreated = true;
    }
    const existingMechanic = await prisma.mechanic.findUnique({
      where: { userId },
      select: { id: true, code: true }
    });
    let mechanic;
    let qrAssigned = false;
    if (existingMechanic) {
      if (assignQrNow && existingMechanic.code) {
        throw createError({
          statusCode: 409,
          statusMessage: "\u0627\u06CC\u0646 \u0645\u06A9\u0627\u0646\u06CC\u06A9 \u0642\u0628\u0644\u0627\u064B \u06A9\u062F QR \u062F\u0627\u0631\u062F"
        });
      }
      if (assignQrNow && !existingMechanic.code) {
        let attempts = 0;
        const maxAttempts = 10;
        let newCode;
        do {
          newCode = generateMechanicCode();
          attempts++;
          const codeExists = await prisma.mechanic.findFirst({
            where: { code: newCode },
            select: { id: true }
          });
          if (!codeExists) break;
          if (attempts >= maxAttempts) {
            throw createError({
              statusCode: 500,
              statusMessage: "\u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646 \u06A9\u062F \u06CC\u06A9\u062A\u0627 \u062A\u0648\u0644\u06CC\u062F \u06A9\u0631\u062F"
            });
          }
        } while (true);
        mechanic = await prisma.mechanic.update({
          where: { id: existingMechanic.id },
          data: {
            code: newCode,
            qrActive: true
          },
          select: {
            id: true,
            code: true,
            qrActive: true,
            createdAt: true,
            user: {
              select: {
                fullName: true,
                phone: true
              }
            }
          }
        });
        qrAssigned = true;
      } else {
        mechanic = await prisma.mechanic.findUnique({
          where: { id: existingMechanic.id },
          select: {
            id: true,
            code: true,
            qrActive: true,
            createdAt: true,
            user: {
              select: {
                fullName: true,
                phone: true
              }
            }
          }
        });
      }
    } else {
      let code = "";
      if (assignQrNow) {
        let attempts = 0;
        const maxAttempts = 10;
        do {
          code = generateMechanicCode();
          attempts++;
          const codeExists = await prisma.mechanic.findFirst({
            where: { code },
            select: { id: true }
          });
          if (!codeExists) break;
          if (attempts >= maxAttempts) {
            throw createError({
              statusCode: 500,
              statusMessage: "\u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646 \u06A9\u062F \u06CC\u06A9\u062A\u0627 \u062A\u0648\u0644\u06CC\u062F \u06A9\u0631\u062F"
            });
          }
        } while (true);
        qrAssigned = true;
      } else {
        code = `TEMP_${userId}_${Date.now()}`;
      }
      mechanic = await prisma.mechanic.create({
        data: {
          userId,
          code,
          qrActive: assignQrNow
        },
        select: {
          id: true,
          code: true,
          qrActive: true,
          createdAt: true,
          user: {
            select: {
              fullName: true,
              phone: true
            }
          }
        }
      });
    }
    logger.info({
      adminId: auth.id,
      mechanicId: mechanic.id,
      userCreated,
      qrAssigned,
      phone: maskPhone(phone),
      action: "CREATE_MECHANIC"
    }, "[ADMIN CREATE MECHANIC API] Mechanic created successfully");
    return {
      ok: true,
      mechanic: {
        id: mechanic.id,
        fullName: mechanic.user.fullName,
        phone: mechanic.user.phone,
        code: mechanic.code,
        qrActive: mechanic.qrActive,
        createdAt: mechanic.createdAt
      },
      userCreated,
      qrAssigned
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid request data"
      });
    }
    logger.error({ err: error }, "[ADMIN CREATE MECHANIC API] Error creating mechanic");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while creating mechanic"
    });
  }
});

export { index_post as default };
//# sourceMappingURL=index.post2.mjs.map
