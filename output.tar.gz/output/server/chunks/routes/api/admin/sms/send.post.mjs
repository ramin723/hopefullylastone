import { c as defineEventHandler, r as readBody, e as createError, h as appendResponseHeader } from '../../../../_/nitro.mjs';
import { r as requireAuth, a as requireRole } from '../../../../_/auth.mjs';
import { k as kavenegarVerifyLookupDebug } from '../../../../_/sms.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../../_/rateLimiter.mjs';
import { c as createRequestLogger } from '../../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/kavenegar/kavenegar.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const send_post = defineEventHandler(async (event) => {
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Admin SMS send debug started");
  const user = await requireAuth(event);
  requireRole(user, "ADMIN");
  const body = await readBody(event);
  const { receptor, template, token } = body;
  if (!receptor) {
    throw createError({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "receptor is required"
    });
  }
  const ip = getClientIP(event);
  const key = `${ip}:${user.id}:sms-debug`;
  const { allowed, remaining, resetAt } = rateLimitComposite({
    key,
    windowMs: 10 * 60 * 1e3,
    // 10 minutes
    max: 5
    // 5 requests per 10 minutes
  });
  if (!allowed) {
    const retryAfterSec = Math.max(1, Math.ceil((resetAt - Date.now()) / 1e3));
    appendResponseHeader(event, "Retry-After", retryAfterSec);
    logger.warn("SMS debug rate-limited", {
      requestId,
      userId: user.id,
      remaining,
      resetAt
    });
    throw createError({
      statusCode: 429,
      statusMessage: "Too Many Requests",
      message: "Too many debug requests. Please try again later."
    });
  }
  logger.info("SMS debug allowed", {
    requestId,
    userId: user.id,
    phone: receptor.replace(/^(\d{4})\d+(\d{4})$/, "$1***$2"),
    remaining,
    resetAt
  });
  try {
    const defaultTemplate = "otp-login";
    const defaultToken = "12345";
    const result = await kavenegarVerifyLookupDebug({
      receptor,
      template: template || defaultTemplate,
      token: token || defaultToken
    });
    logger.info("SMS verifylookup debug completed", {
      requestId,
      userId: user.id,
      ok: result.ok,
      status: result.status
    });
    return result;
  } catch (error) {
    logger.error("SMS verifylookup debug failed", {
      requestId,
      userId: user.id,
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      message: "Failed to test SMS verifylookup"
    });
  }
});

export { send_post as default };
//# sourceMappingURL=send.post.mjs.map
