import { c as defineEventHandler, r as readBody, e as createError, h as appendResponseHeader } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { c as createRequestLogger } from '../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { g as getClientIP, h as hashPhone, r as rateLimitComposite, m as maskPhone } from '../../../_/rateLimiter.mjs';
import { C as CreateInviteSchema } from '../../../_/invite.mjs';
import { i as inviteActiveWhere, a as generateInviteToken, h as hashToken, s as sendInviteSms } from '../../../_/invite2.mjs';
import { n as normalizePhone } from '../../../_/otp.mjs';
import { r as requireAuth, a as requireRole } from '../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';
import 'file://D:/hamkari/node_modules/zod/index.js';
import '../../../_/sms.mjs';
import 'file://D:/hamkari/node_modules/kavenegar/kavenegar.js';

const index_post = defineEventHandler(async (event) => {
  var _a;
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Admin invite creation started");
  const user = await requireAuth(event);
  requireRole(user, "ADMIN");
  const body = await readBody(event);
  const validation = CreateInviteSchema.safeParse(body);
  if (!validation.success) {
    logger.error("Invite creation validation failed", {
      errors: validation.error.issues.map((e) => e.message)
    });
    throw createError({
      statusCode: 400,
      statusMessage: ((_a = validation.error.issues[0]) == null ? void 0 : _a.message) || "Invalid input"
    });
  }
  const { role, phone, fullName, city, specialties, storeName, addressLine, province, postalCode } = validation.data;
  const normalizedPhone = normalizePhone(phone);
  const ip = getClientIP(event);
  const phoneHash = hashPhone(normalizedPhone);
  const key = `${ip}:${phoneHash}:invite`;
  const { allowed, remaining, resetAt } = rateLimitComposite({
    key,
    windowMs: 10 * 60 * 1e3,
    // 10 minutes
    max: 10
    // 10 requests per 10 minutes
  });
  if (!allowed) {
    const retryAfterSec = Math.max(1, Math.ceil((resetAt - Date.now()) / 1e3));
    appendResponseHeader(event, "Retry-After", retryAfterSec);
    logger.warn("Invite creation rate-limited", {
      requestId,
      phone: maskPhone(normalizedPhone),
      remaining,
      resetAt
    });
    throw createError({
      statusCode: 429,
      statusMessage: "Too Many Requests",
      message: "Too many invite requests. Please try again later."
    });
  }
  logger.info("Invite creation allowed", {
    requestId,
    phone: maskPhone(normalizedPhone),
    role,
    remaining,
    resetAt
  });
  try {
    const existingUser = await prisma.user.findFirst({
      where: {
        phone: normalizedPhone,
        role,
        status: "ACTIVE"
      },
      include: {
        Mechanic: role === "MECHANIC",
        Vendor: role === "VENDOR"
      }
    });
    if (existingUser) {
      logger.warn("User already exists with this role", {
        requestId,
        phone: maskPhone(normalizedPhone),
        role,
        userId: existingUser.id
      });
      throw createError({
        statusCode: 409,
        statusMessage: "Conflict",
        message: "\u06A9\u0627\u0631\u0628\u0631\u06CC \u0628\u0627 \u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0648 \u0646\u0642\u0634 \u0627\u0632 \u0642\u0628\u0644 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F"
      });
    }
    const existingInvite = await prisma.invite.findFirst({
      where: inviteActiveWhere(normalizedPhone, role)
    });
    if (existingInvite) {
      logger.warn("Active invite already exists", {
        requestId,
        phone: maskPhone(normalizedPhone),
        role,
        inviteId: existingInvite.id
      });
      throw createError({
        statusCode: 409,
        statusMessage: "Conflict",
        message: "\u062F\u0639\u0648\u062A \u0641\u0639\u0627\u0644\u06CC \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0648 \u0646\u0642\u0634 \u0627\u0632 \u0642\u0628\u0644 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F"
      });
    }
    const token = generateInviteToken(16);
    const codeHash = hashToken(token);
    const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1e3);
    const meta = {};
    if (fullName) meta.fullName = fullName;
    if (city) meta.city = city;
    if (specialties) meta.specialties = specialties;
    if (storeName) meta.storeName = storeName;
    if (addressLine) meta.addressLine = addressLine;
    if (province) meta.province = province;
    if (postalCode) meta.postalCode = postalCode;
    const result = await prisma.$transaction(async (tx) => {
      const invite = await tx.invite.create({
        data: {
          role,
          phone: normalizedPhone,
          codeHash,
          expiresAt,
          createdBy: user.id,
          meta: Object.keys(meta).length > 0 ? meta : null
        }
      });
      const smsResult = await sendInviteSms(normalizedPhone, token, role, fullName);
      if (!smsResult.sent) {
        throw createError({
          statusCode: 502,
          statusMessage: "SMS Service Unavailable",
          message: smsResult.error || "\u0627\u06CC\u062C\u0627\u062F \u062F\u0639\u0648\u062A \u0627\u0646\u062C\u0627\u0645 \u0646\u0634\u062F (\u0627\u0631\u0633\u0627\u0644 \u067E\u06CC\u0627\u0645\u06A9 \u0646\u0627\u0645\u0648\u0641\u0642)."
        });
      }
      const updatedInvite = await tx.invite.update({
        where: { id: invite.id },
        data: { sent: smsResult.sent }
      });
      return { invite: updatedInvite, smsResult };
    });
    logger.info("Invite created and SMS sent successfully", {
      requestId,
      inviteId: result.invite.id,
      phone: maskPhone(normalizedPhone),
      role,
      expiresAt
    });
    return {
      ok: true,
      message: "\u062F\u0639\u0648\u062A \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0631\u0633\u0627\u0644 \u0634\u062F",
      data: {
        inviteId: result.invite.id,
        sent: result.smsResult.sent,
        token: false ? token : void 0,
        // Only return token in dev
        link: false ? `${process.env.NUXT_PUBLIC_BASE_URL || "http://localhost:3000"}/invite/${token}` : void 0
      }
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error("Invite creation failed", {
      requestId,
      phone: maskPhone(normalizedPhone),
      role,
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      message: "Failed to create invite"
    });
  }
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
