import { c as defineEventHandler, f as getRouterParam, e as createError } from '../../../../../_/nitro.mjs';
import { r as requireAuth, a as requireRole } from '../../../../../_/auth.mjs';
import { prisma } from '../../../../../_/db.mjs';
import { c as createRequestLogger } from '../../../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { m as maskPhone } from '../../../../../_/rateLimiter.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const cancel_post = defineEventHandler(async (event) => {
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Admin invite cancel started");
  const user = await requireAuth(event);
  requireRole(user, "ADMIN");
  const inviteId = parseInt(getRouterParam(event, "id") || "0");
  if (!inviteId || inviteId <= 0) {
    throw createError({
      statusCode: 400,
      statusMessage: "Bad Request",
      message: "Invalid invite ID"
    });
  }
  try {
    const result = await prisma.$transaction(async (tx) => {
      const invite = await tx.invite.findUnique({
        where: { id: inviteId },
        include: { createdByUser: true }
      });
      if (!invite) {
        throw createError({
          statusCode: 404,
          statusMessage: "Not Found",
          message: "\u062F\u0639\u0648\u062A \u06CC\u0627\u0641\u062A \u0646\u0634\u062F"
        });
      }
      if (invite.canceledAt) {
        throw createError({
          statusCode: 409,
          statusMessage: "Conflict",
          message: "\u0627\u06CC\u0646 \u062F\u0639\u0648\u062A \u0642\u0628\u0644\u0627\u064B \u0644\u063A\u0648 \u0634\u062F\u0647 \u0627\u0633\u062A"
        });
      }
      if (invite.usedAt) {
        throw createError({
          statusCode: 409,
          statusMessage: "Conflict",
          message: "\u0627\u06CC\u0646 \u062F\u0639\u0648\u062A \u0642\u0628\u0644\u0627\u064B \u0627\u0633\u062A\u0641\u0627\u062F\u0647 \u0634\u062F\u0647 \u0627\u0633\u062A"
        });
      }
      const canceledAt = /* @__PURE__ */ new Date();
      const updatedInvite = await tx.invite.update({
        where: { id: inviteId },
        data: {
          canceledAt,
          expiresAt: canceledAt
          // Set expiresAt to now to make it immediately expired
        }
      });
      return { invite: updatedInvite, canceledAt };
    });
    logger.info("Invite canceled successfully", {
      requestId,
      inviteId,
      phone: maskPhone(result.invite.phone),
      role: result.invite.role,
      canceledAt: result.canceledAt
    });
    return {
      ok: true,
      canceledAt: result.canceledAt.toISOString(),
      id: result.invite.id
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error("Invite cancel failed", {
      requestId,
      inviteId,
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      message: "Failed to cancel invite"
    });
  }
});

export { cancel_post as default };
//# sourceMappingURL=cancel.post.mjs.map
