import { c as defineEventHandler, g as getQuery, e as createError } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { c as createRequestLogger } from '../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { I as InviteListQuerySchema } from '../../../_/invite.mjs';
import { g as getInviteStatus } from '../../../_/invite2.mjs';
import { m as maskPhone } from '../../../_/rateLimiter.mjs';
import { r as requireAuth, a as requireRole } from '../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';
import 'file://D:/hamkari/node_modules/zod/index.js';
import '../../../_/otp.mjs';
import '../../../_/sms.mjs';
import 'file://D:/hamkari/node_modules/kavenegar/kavenegar.js';

const index_get = defineEventHandler(async (event) => {
  var _a;
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Admin invite list request started");
  const user = await requireAuth(event);
  requireRole(user, "ADMIN");
  const query = getQuery(event);
  const validation = InviteListQuerySchema.safeParse(query);
  if (!validation.success) {
    logger.error("Invite list query validation failed", {
      errors: validation.error.issues.map((e) => e.message)
    });
    throw createError({
      statusCode: 400,
      statusMessage: ((_a = validation.error.issues[0]) == null ? void 0 : _a.message) || "Invalid query parameters"
    });
  }
  const { role, phone, status, page, limit } = validation.data;
  const skip = (page - 1) * limit;
  logger.info("Admin invite list request allowed", {
    requestId,
    filters: { role, phone: phone ? maskPhone(phone) : null, status },
    pagination: { page, limit, skip }
  });
  const totalCount = await prisma.invite.count();
  logger.info("Total invites in database", { requestId, totalCount });
  try {
    const where = {};
    if (role) {
      where.role = role;
    }
    if (phone) {
      where.phone = {
        contains: phone
      };
    }
    if (status) {
      const now = /* @__PURE__ */ new Date();
      switch (status) {
        case "ACTIVE":
          where.usedAt = null;
          where.canceledAt = null;
          where.expiresAt = { gt: now };
          break;
        case "USED":
          where.usedAt = { not: null };
          break;
        case "EXPIRED":
          where.usedAt = null;
          where.canceledAt = null;
          where.expiresAt = { lte: now };
          break;
        case "CANCELED":
          where.canceledAt = { not: null };
          break;
      }
    }
    logger.info("Where clause for invite query", { requestId, where });
    const [invites, total] = await Promise.all([
      prisma.invite.findMany({
        where,
        include: {
          createdByUser: {
            select: {
              id: true,
              fullName: true,
              phone: true
            }
          }
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: limit
      }),
      prisma.invite.count({ where })
    ]);
    const transformedInvites = invites.map((invite) => {
      const inviteWithCanceledAt = invite;
      return {
        id: invite.id,
        role: invite.role,
        phone: maskPhone(invite.phone),
        status: getInviteStatus({
          expiresAt: invite.expiresAt,
          usedAt: invite.usedAt,
          canceledAt: inviteWithCanceledAt.canceledAt,
          meta: invite.meta
        }),
        expiresAt: invite.expiresAt,
        usedAt: invite.usedAt,
        canceledAt: inviteWithCanceledAt.canceledAt,
        createdAt: invite.createdAt,
        createdBy: {
          id: invite.createdByUser.id,
          fullName: invite.createdByUser.fullName,
          phone: maskPhone(invite.createdByUser.phone)
        },
        meta: invite.meta
      };
    });
    const totalPages = Math.ceil(total / limit);
    logger.info("Admin invite list retrieved successfully", {
      requestId,
      total,
      returned: transformedInvites.length,
      page,
      totalPages
    });
    return {
      ok: true,
      data: {
        invites: transformedInvites,
        pagination: {
          page,
          limit,
          total,
          totalPages,
          hasNext: page < totalPages,
          hasPrev: page > 1
        }
      }
    };
  } catch (error) {
    logger.error("Admin invite list request failed", {
      requestId,
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      message: "Failed to retrieve invite list"
    });
  }
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
