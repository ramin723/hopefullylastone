import { c as defineEventHandler, g as getQuery, e as createError } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { c as createRequestLogger } from '../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { r as requireAuth, a as requireRole } from '../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const index_get = defineEventHandler(async (event) => {
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Admin vendors list request started");
  const user = await requireAuth(event);
  requireRole(user, "ADMIN");
  const query = getQuery(event);
  const search = query.search || "";
  const status = query.status || "";
  const suspended = query.suspended || "";
  const page = parseInt(query.page) || 1;
  const pageSize = parseInt(query.pageSize) || 20;
  const skip = (page - 1) * pageSize;
  logger.info("Admin vendors list request allowed", {
    requestId,
    filters: { search, status, suspended },
    pagination: { page, pageSize, skip }
  });
  try {
    const where = {};
    if (search) {
      where.OR = [
        { storeName: { contains: search, mode: "insensitive" } },
        { city: { contains: search, mode: "insensitive" } },
        { user: { phone: { contains: search } } },
        { user: { fullName: { contains: search, mode: "insensitive" } } }
      ];
    }
    if (status) {
      where.status = status;
    }
    if (suspended) {
      if (suspended === "true") {
        where.user = { ...where.user, suspendedAt: { not: null } };
      } else if (suspended === "false") {
        where.user = { ...where.user, suspendedAt: null };
      }
    }
    const [vendors, total] = await Promise.all([
      prisma.vendor.findMany({
        where,
        include: {
          user: {
            select: {
              id: true,
              fullName: true,
              phone: true,
              status: true,
              suspendedAt: true,
              suspendReason: true
            }
          }
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: pageSize
      }),
      prisma.vendor.count({ where })
    ]);
    const transformedVendors = vendors.map((vendor) => ({
      id: vendor.id,
      storeName: vendor.storeName,
      city: vendor.city,
      status: vendor.status,
      createdAt: vendor.createdAt,
      fullName: vendor.user.fullName,
      phone: vendor.user.phone,
      userStatus: vendor.user.status,
      suspended: !!vendor.user.suspendedAt,
      suspendedAt: vendor.user.suspendedAt,
      suspendReason: vendor.user.suspendReason
    }));
    logger.info("Admin vendors list retrieved successfully", {
      requestId,
      total,
      returned: transformedVendors.length,
      page,
      pageSize
    });
    return {
      items: transformedVendors,
      count: total
    };
  } catch (error) {
    logger.error("Admin vendors list request failed", {
      requestId,
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      message: "Failed to retrieve vendors list"
    });
  }
});

export { index_get as default };
//# sourceMappingURL=index.get3.mjs.map
