import { c as defineEventHandler, g as getQuery, e as createError } from '../../../../_/nitro.mjs';
import { prisma } from '../../../../_/db.mjs';
import { c as createRequestLogger } from '../../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { r as requireAuth, a as requireRole } from '../../../../_/auth.mjs';
import { n as normalizePhone } from '../../../../_/otp.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const userByPhone_get = defineEventHandler(async (event) => {
  var _a;
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Admin debug user-by-phone request started");
  const user = await requireAuth(event);
  requireRole(user, "ADMIN");
  const query = getQuery(event);
  const phone = query.phone;
  if (!phone) {
    logger.error("Admin debug user-by-phone missing phone parameter", {
      requestId,
      adminId: user.id
    });
    throw createError({
      statusCode: 400,
      statusMessage: "Phone parameter is required"
    });
  }
  try {
    const normalizedPhone = normalizePhone(phone);
    logger.info("Admin debug user-by-phone search started", {
      requestId,
      adminId: user.id,
      searchPhone: normalizedPhone
    });
    const foundUser = await prisma.user.findUnique({
      where: {
        phone: normalizedPhone
      },
      select: {
        id: true,
        role: true,
        phone: true,
        mustChangePassword: true,
        passwordHash: true,
        createdAt: true,
        refreshTokens: {
          select: {
            createdAt: true
          },
          orderBy: {
            createdAt: "desc"
          },
          take: 1
        }
      }
    });
    if (!foundUser) {
      logger.warn("Admin debug user-by-phone user not found", {
        requestId,
        adminId: user.id,
        searchPhone: normalizedPhone
      });
      return {
        ok: true,
        user: null,
        note: "User not found - no PII beyond masked"
      };
    }
    const maskedPhone = foundUser.phone.replace(/^(\d{4})\d+(\d{4})$/, "$1***$2");
    const hasPassword = foundUser.passwordHash && foundUser.passwordHash.length > 0;
    const lastLoginAt = foundUser.refreshTokens.length > 0 ? (_a = foundUser.refreshTokens[0]) == null ? void 0 : _a.createdAt : null;
    const result = {
      ok: true,
      user: {
        id: foundUser.id,
        role: foundUser.role,
        phone: maskedPhone,
        mustChangePassword: foundUser.mustChangePassword,
        hasPassword,
        createdAt: foundUser.createdAt,
        lastLoginAt
      },
      note: "no PII beyond masked"
    };
    logger.info("Admin debug user-by-phone completed", {
      requestId,
      adminId: user.id,
      foundUserId: foundUser.id,
      foundUserRole: foundUser.role,
      mustChangePassword: foundUser.mustChangePassword,
      hasPassword
    });
    return result;
  } catch (error) {
    logger.error("Admin debug user-by-phone failed", {
      requestId,
      adminId: user.id,
      searchPhone: phone,
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error"
    });
  }
});

export { userByPhone_get as default };
//# sourceMappingURL=user-by-phone.get.mjs.map
