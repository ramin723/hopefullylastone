import { c as defineEventHandler, e as createError, g as getQuery } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../_/rateLimiter.mjs';
import { l as logger } from '../../../_/logger.mjs';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const QuerySchema = z.object({
  search: z.string().optional(),
  qrActive: z.enum(["true", "false"]).optional(),
  city: z.string().optional(),
  tier: z.enum(["BASIC", "PRO", "ELITE"]).optional(),
  suspended: z.enum(["true", "false"]).optional(),
  page: z.string().regex(/^\d+$/).transform(Number).default(() => 1),
  pageSize: z.string().regex(/^\d+$/).transform(Number).default(() => 20)
});
const index_get = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const ip = getClientIP(event);
    const rateKey = `admin.mechanics.list:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 5 * 60 * 1e3,
      // 5 minutes
      max: 60
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many requests"
      });
    }
    const query = getQuery(event);
    const { search, qrActive, city, tier, suspended, page, pageSize } = QuerySchema.parse(query);
    const skip = (page - 1) * pageSize;
    const take = pageSize;
    const where = {};
    if (search) {
      where.OR = [
        { user: { fullName: { contains: search, mode: "insensitive" } } },
        { user: { phone: { contains: search, mode: "insensitive" } } },
        { code: { contains: search, mode: "insensitive" } }
      ];
    }
    if (qrActive === "true") {
      where.qrActive = true;
    } else if (qrActive === "false") {
      where.qrActive = false;
    }
    if (city) {
      where.city = { contains: city, mode: "insensitive" };
    }
    if (tier) {
      where.tier = tier;
    }
    if (suspended === "true") {
      where.user = { ...where.user, suspendedAt: { not: null } };
    } else if (suspended === "false") {
      where.user = { ...where.user, suspendedAt: null };
    }
    const [mechanics, totalCount] = await Promise.all([
      prisma.mechanic.findMany({
        where,
        skip,
        take,
        include: {
          user: true
        },
        orderBy: { createdAt: "desc" }
      }),
      prisma.mechanic.count({ where })
    ]);
    const maskedMechanics = mechanics.map((mechanic) => ({
      id: mechanic.id,
      fullName: mechanic.user.fullName,
      phone: mechanic.user.phone ? `${mechanic.user.phone.slice(0, 3)}***${mechanic.user.phone.slice(-2)}` : "\u0646\u0627\u0645\u0634\u062E\u0635",
      code: mechanic.code,
      qrActive: mechanic.qrActive,
      city: mechanic.city,
      tier: mechanic.tier,
      specialties: mechanic.specialties,
      suspended: !!mechanic.user.suspendedAt,
      suspendedAt: mechanic.user.suspendedAt,
      suspendReason: mechanic.user.suspendReason,
      createdAt: mechanic.createdAt
    }));
    logger.info({
      adminId: auth.id,
      searchTerm: search ? "***" : null,
      qrActiveFilter: qrActive,
      cityFilter: city,
      tierFilter: tier,
      suspendedFilter: suspended,
      page,
      pageSize,
      resultCount: maskedMechanics.length,
      totalCount,
      ip
    }, "[ADMIN MECHANICS LIST API] Mechanics list retrieved");
    return {
      ok: true,
      items: maskedMechanics,
      pagination: {
        page,
        pageSize,
        totalCount,
        totalPages: Math.ceil(totalCount / pageSize),
        hasMore: page < Math.ceil(totalCount / pageSize)
      }
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid query parameters",
        data: { errors: error.issues }
      });
    }
    logger.error({ err: error }, "[ADMIN MECHANICS LIST API] Error retrieving mechanics list");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while retrieving mechanics list"
    });
  }
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
