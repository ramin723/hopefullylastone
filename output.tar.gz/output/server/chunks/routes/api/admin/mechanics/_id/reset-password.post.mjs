import { c as defineEventHandler, e as createError } from '../../../../../_/nitro.mjs';
import { prisma } from '../../../../../_/db.mjs';
import { r as requireAuth } from '../../../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../../../_/rateLimiter.mjs';
import { l as logger } from '../../../../../_/logger.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const resetPassword_post = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const ip = getClientIP(event);
    const rateKey = `admin.mechanic.reset-password:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 10 * 60 * 1e3,
      // 10 minutes
      max: 20
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many requests"
      });
    }
    const mechanicId = parseInt(event.context.params.id);
    if (!mechanicId || isNaN(mechanicId)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid mechanic ID"
      });
    }
    const currentMechanic = await prisma.mechanic.findUnique({
      where: { id: mechanicId },
      select: {
        id: true,
        userId: true,
        user: {
          select: {
            fullName: true,
            mustChangePassword: true,
            passwordHash: true
          }
        }
      }
    });
    if (!currentMechanic) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mechanic not found"
      });
    }
    if (currentMechanic.user.mustChangePassword && !currentMechanic.user.passwordHash) {
      throw createError({
        statusCode: 409,
        statusMessage: "User already needs to change password"
      });
    }
    const result = await prisma.$transaction(async (tx) => {
      const resetUser = await tx.user.update({
        where: { id: currentMechanic.userId },
        data: {
          passwordHash: "",
          mustChangePassword: true
        },
        select: { id: true, mustChangePassword: true, passwordHash: true }
      });
      await tx.refreshToken.updateMany({
        where: {
          userId: currentMechanic.userId,
          revokedAt: null
        },
        data: { revokedAt: /* @__PURE__ */ new Date() }
      });
      return resetUser;
    });
    logger.warn({
      adminId: auth.id,
      mechanicId: currentMechanic.id,
      mechanicName: currentMechanic.user.fullName,
      userId: currentMechanic.userId,
      previousMustChangePassword: currentMechanic.user.mustChangePassword,
      ip
    }, "[ADMIN MECHANIC RESET PASSWORD API] Password reset - SECURITY EVENT");
    return {
      ok: true,
      mechanicId: currentMechanic.id,
      userId: currentMechanic.userId,
      mustChangePassword: result.mustChangePassword,
      passwordReset: true
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error({ err: error }, "[ADMIN MECHANIC RESET PASSWORD API] Error resetting password");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while resetting password"
    });
  }
});

export { resetPassword_post as default };
//# sourceMappingURL=reset-password.post.mjs.map
