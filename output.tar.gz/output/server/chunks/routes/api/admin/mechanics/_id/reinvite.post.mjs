import { c as defineEventHandler, e as createError } from '../../../../../_/nitro.mjs';
import { prisma } from '../../../../../_/db.mjs';
import { r as requireAuth } from '../../../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../../../_/rateLimiter.mjs';
import { l as logger } from '../../../../../_/logger.mjs';
import { i as inviteActiveWhere, a as generateInviteToken, h as hashToken, s as sendInviteSms } from '../../../../../_/invite2.mjs';
import { n as normalizePhone } from '../../../../../_/otp.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';
import '../../../../../_/sms.mjs';
import 'file://D:/hamkari/node_modules/kavenegar/kavenegar.js';

const reinvite_post = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const ip = getClientIP(event);
    const rateKey = `admin.mechanic.reinvite:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 10 * 60 * 1e3,
      // 10 minutes
      max: 10
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many requests"
      });
    }
    const mechanicId = parseInt(event.context.params.id);
    if (!mechanicId || isNaN(mechanicId)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid mechanic ID"
      });
    }
    const currentMechanic = await prisma.mechanic.findUnique({
      where: { id: mechanicId },
      select: {
        id: true,
        userId: true,
        user: {
          select: {
            fullName: true,
            phone: true
          }
        }
      }
    });
    if (!currentMechanic) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mechanic not found"
      });
    }
    const phone = normalizePhone(currentMechanic.user.phone);
    const existingInvite = await prisma.invite.findFirst({
      where: inviteActiveWhere(phone, "MECHANIC")
    });
    if (existingInvite) {
      throw createError({
        statusCode: 409,
        statusMessage: "Active invite already exists for this mechanic"
      });
    }
    const token = generateInviteToken(16);
    const codeHash = hashToken(token);
    const expiresAt = new Date(Date.now() + 48 * 60 * 60 * 1e3);
    const result = await prisma.$transaction(async (tx) => {
      const invite = await tx.invite.create({
        data: {
          role: "MECHANIC",
          phone,
          codeHash,
          expiresAt,
          createdBy: auth.id,
          meta: {
            fullName: currentMechanic.user.fullName,
            mechanicId: currentMechanic.id
          }
        }
      });
      const smsResult = await sendInviteSms(phone, token, "MECHANIC", currentMechanic.user.fullName);
      if (!smsResult.sent) {
        throw createError({
          statusCode: 502,
          statusMessage: "SMS Service Unavailable",
          message: smsResult.error || "Failed to send invite SMS"
        });
      }
      const updatedInvite = await tx.invite.update({
        where: { id: invite.id },
        data: { sent: smsResult.sent }
      });
      return { invite: updatedInvite, smsResult };
    });
    logger.info({
      adminId: auth.id,
      mechanicId: currentMechanic.id,
      mechanicName: currentMechanic.user.fullName,
      phone: phone.slice(0, 3) + "***" + phone.slice(-2),
      // Masked phone
      inviteId: result.invite.id,
      expiresAt,
      ip
    }, "[ADMIN MECHANIC REINVITE API] Invite sent to mechanic");
    return {
      ok: true,
      mechanicId: currentMechanic.id,
      inviteId: result.invite.id,
      sent: result.smsResult.sent,
      expiresAt,
      token: false ? token : void 0,
      // Only return token in dev
      link: false ? `${process.env.NUXT_PUBLIC_BASE_URL || "http://localhost:3000"}/invite/${token}` : void 0
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error({ err: error }, "[ADMIN MECHANIC REINVITE API] Error sending reinvite");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while sending reinvite"
    });
  }
});

export { reinvite_post as default };
//# sourceMappingURL=reinvite.post.mjs.map
