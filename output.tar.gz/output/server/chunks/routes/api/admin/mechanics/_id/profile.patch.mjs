import { c as defineEventHandler, e as createError, r as readBody } from '../../../../../_/nitro.mjs';
import { prisma } from '../../../../../_/db.mjs';
import { r as requireAuth } from '../../../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../../../_/rateLimiter.mjs';
import { l as logger } from '../../../../../_/logger.mjs';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const BodySchema = z.object({
  fullName: z.string().trim().min(1).max(100).optional(),
  city: z.string().trim().max(50).optional(),
  tier: z.enum(["BASIC", "PRO", "ELITE"]).optional(),
  specialties: z.string().trim().max(500).optional()
});
const profile_patch = defineEventHandler(async (event) => {
  var _a;
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const ip = getClientIP(event);
    const rateKey = `admin.mechanic.profile:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 5 * 60 * 1e3,
      // 5 minutes
      max: 30
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many requests"
      });
    }
    const mechanicId = parseInt(event.context.params.id);
    if (!mechanicId || isNaN(mechanicId)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid mechanic ID"
      });
    }
    const body = await readBody(event);
    const validatedBody = BodySchema.parse(body);
    const existingMechanic = await prisma.mechanic.findUnique({
      where: { id: mechanicId },
      select: {
        id: true,
        user: {
          select: {
            id: true,
            fullName: true
          }
        }
      }
    });
    if (!existingMechanic) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mechanic not found"
      });
    }
    const result = await prisma.$transaction(async (tx) => {
      const updatedMechanic = await tx.mechanic.update({
        where: { id: mechanicId },
        data: {
          city: validatedBody.city,
          tier: validatedBody.tier,
          specialties: validatedBody.specialties
        },
        select: {
          id: true,
          city: true,
          tier: true,
          specialties: true
        }
      });
      let updatedUser = null;
      if (validatedBody.fullName) {
        updatedUser = await tx.user.update({
          where: { id: existingMechanic.user.id },
          data: { fullName: validatedBody.fullName },
          select: { id: true, fullName: true }
        });
      }
      return { updatedMechanic, updatedUser };
    });
    logger.info({
      adminId: auth.id,
      mechanicId: existingMechanic.id,
      mechanicName: existingMechanic.user.fullName,
      updatedFields: Object.keys(validatedBody),
      ip
    }, "[ADMIN MECHANIC PROFILE API] Mechanic profile updated");
    return {
      ok: true,
      mechanicId: result.updatedMechanic.id,
      updated: {
        fullName: (_a = result.updatedUser) == null ? void 0 : _a.fullName,
        city: result.updatedMechanic.city,
        tier: result.updatedMechanic.tier,
        specialties: result.updatedMechanic.specialties
      }
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid request body",
        data: { errors: error.issues }
      });
    }
    logger.error({ err: error }, "[ADMIN MECHANIC PROFILE API] Error updating mechanic profile");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while updating mechanic profile"
    });
  }
});

export { profile_patch as default };
//# sourceMappingURL=profile.patch.mjs.map
