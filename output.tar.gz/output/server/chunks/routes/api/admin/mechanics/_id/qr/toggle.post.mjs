import { c as defineEventHandler, e as createError, r as readBody } from '../../../../../../_/nitro.mjs';
import { prisma } from '../../../../../../_/db.mjs';
import { r as requireAuth } from '../../../../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../../../../_/rateLimiter.mjs';
import { l as logger } from '../../../../../../_/logger.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const toggle_post = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const ip = getClientIP(event);
    const rateKey = `admin.mechanic.qr.toggle:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 5 * 60 * 1e3,
      // 5 minutes
      max: 20
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many requests"
      });
    }
    const mechanicId = parseInt(event.context.params.id);
    if (!mechanicId || isNaN(mechanicId)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid mechanic ID"
      });
    }
    const body = await readBody(event);
    if (!body || typeof body.active !== "boolean") {
      throw createError({
        statusCode: 400,
        statusMessage: "Missing or invalid active parameter"
      });
    }
    const existingMechanic = await prisma.mechanic.findUnique({
      where: { id: mechanicId },
      select: { id: true, code: true, qrActive: true }
    });
    if (!existingMechanic) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mechanic not found"
      });
    }
    const updatedMechanic = await prisma.mechanic.update({
      where: { id: mechanicId },
      data: { qrActive: body.active },
      select: { id: true, code: true, qrActive: true }
    });
    logger.info({
      adminId: auth.id,
      mechanicId: updatedMechanic.id,
      mechanicCode: updatedMechanic.code,
      previousStatus: existingMechanic.qrActive,
      newStatus: body.active,
      action: "QR_TOGGLE"
    }, "[ADMIN MECHANIC QR TOGGLE API] QR status updated");
    return {
      ok: true,
      mechanic: {
        id: updatedMechanic.id,
        code: updatedMechanic.code,
        qrActive: updatedMechanic.qrActive
      },
      message: `QR ${body.active ? "\u0641\u0639\u0627\u0644" : "\u063A\u06CC\u0631\u0641\u0639\u0627\u0644"} \u0634\u062F`
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error({ err: error }, "[ADMIN MECHANIC QR TOGGLE API] Error toggling QR status");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while updating QR status"
    });
  }
});

export { toggle_post as default };
//# sourceMappingURL=toggle.post.mjs.map
