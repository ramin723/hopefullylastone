import { c as defineEventHandler, e as createError, r as readBody } from '../../../../../_/nitro.mjs';
import { prisma } from '../../../../../_/db.mjs';
import { r as requireAuth } from '../../../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../../../_/rateLimiter.mjs';
import { l as logger } from '../../../../../_/logger.mjs';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const BodySchema = z.object({
  reason: z.string().trim().max(200).optional()
});
const suspend_post = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const ip = getClientIP(event);
    const rateKey = `admin.mechanic.suspend:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 10 * 60 * 1e3,
      // 10 minutes
      max: 20
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many requests"
      });
    }
    const mechanicId = parseInt(event.context.params.id);
    if (!mechanicId || isNaN(mechanicId)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid mechanic ID"
      });
    }
    const body = await readBody(event);
    const validatedBody = BodySchema.parse(body);
    const currentMechanic = await prisma.mechanic.findUnique({
      where: { id: mechanicId },
      select: {
        id: true,
        userId: true,
        user: {
          select: {
            fullName: true,
            suspendedAt: true,
            suspendReason: true
          }
        }
      }
    });
    if (!currentMechanic) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mechanic not found"
      });
    }
    if (currentMechanic.user.suspendedAt) {
      throw createError({
        statusCode: 409,
        statusMessage: "User is already suspended"
      });
    }
    const result = await prisma.$transaction(async (tx) => {
      const suspendedUser = await tx.user.update({
        where: { id: currentMechanic.userId },
        data: {
          suspendedAt: /* @__PURE__ */ new Date(),
          suspendReason: validatedBody.reason || null
        },
        select: { id: true, suspendedAt: true, suspendReason: true }
      });
      await tx.refreshToken.updateMany({
        where: {
          userId: currentMechanic.userId,
          revokedAt: null
        },
        data: { revokedAt: /* @__PURE__ */ new Date() }
      });
      return suspendedUser;
    });
    logger.warn({
      adminId: auth.id,
      mechanicId: currentMechanic.id,
      mechanicName: currentMechanic.user.fullName,
      userId: currentMechanic.userId,
      suspendReason: validatedBody.reason,
      suspendedAt: result.suspendedAt,
      ip
    }, "[ADMIN MECHANIC SUSPEND API] User suspended - SECURITY EVENT");
    return {
      ok: true,
      mechanicId: currentMechanic.id,
      userId: currentMechanic.userId,
      suspended: true,
      suspendedAt: result.suspendedAt,
      suspendReason: result.suspendReason
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    if (error.name === "ZodError") {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid request body",
        data: { errors: error.issues }
      });
    }
    logger.error({ err: error }, "[ADMIN MECHANIC SUSPEND API] Error suspending user");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while suspending user"
    });
  }
});

export { suspend_post as default };
//# sourceMappingURL=suspend.post.mjs.map
