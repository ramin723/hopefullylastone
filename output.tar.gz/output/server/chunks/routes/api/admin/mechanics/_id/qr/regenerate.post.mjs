import { c as defineEventHandler, e as createError } from '../../../../../../_/nitro.mjs';
import { prisma } from '../../../../../../_/db.mjs';
import { r as requireAuth } from '../../../../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../../../../_/rateLimiter.mjs';
import { l as logger } from '../../../../../../_/logger.mjs';
import { g as generateMechanicCode } from '../../../../../../_/ids.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const regenerate_post = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const ip = getClientIP(event);
    const rateKey = `admin.mechanic.qr.regenerate:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 60 * 60 * 1e3,
      // 1 hour
      max: 5
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many regeneration requests. Please wait before trying again."
      });
    }
    const mechanicId = parseInt(event.context.params.id);
    if (!mechanicId || isNaN(mechanicId)) {
      throw createError({
        statusCode: 400,
        statusMessage: "Invalid mechanic ID"
      });
    }
    const existingMechanic = await prisma.mechanic.findUnique({
      where: { id: mechanicId },
      select: { id: true, code: true, qrActive: true }
    });
    if (!existingMechanic) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mechanic not found"
      });
    }
    let newCode;
    let attempts = 0;
    const maxAttempts = 10;
    do {
      newCode = generateMechanicCode();
      attempts++;
      const existing = await prisma.mechanic.findFirst({
        where: { code: newCode },
        select: { id: true }
      });
      if (!existing) break;
      if (attempts >= maxAttempts) {
        throw createError({
          statusCode: 500,
          statusMessage: "Unable to generate unique code after multiple attempts"
        });
      }
    } while (true);
    const updatedMechanic = await prisma.mechanic.update({
      where: { id: mechanicId },
      data: {
        code: newCode,
        qrActive: true
        // Always activate when regenerating
      },
      select: { id: true, code: true, qrActive: true }
    });
    logger.warn({
      adminId: auth.id,
      mechanicId: existingMechanic.id,
      oldCode: existingMechanic.code,
      newCode,
      action: "QR_REGENERATE",
      ip,
      userAgent: event.headers.get("user-agent") || "unknown"
    }, "[ADMIN MECHANIC QR REGENERATE API] QR code regenerated - SECURITY EVENT");
    return {
      ok: true,
      mechanic: {
        id: updatedMechanic.id,
        code: updatedMechanic.code,
        qrActive: updatedMechanic.qrActive
      },
      message: "\u06A9\u062F QR \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0628\u0627\u0632\u062A\u0648\u0644\u06CC\u062F \u0634\u062F \u0648 \u0641\u0639\u0627\u0644 \u0634\u062F",
      warning: "\u06A9\u062F \u0642\u0628\u0644\u06CC \u0628\u0627\u0637\u0644 \u0634\u062F\u0647 \u0627\u0633\u062A"
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error({ err: error }, "[ADMIN MECHANIC QR REGENERATE API] Error regenerating QR code");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while regenerating QR code"
    });
  }
});

export { regenerate_post as default };
//# sourceMappingURL=regenerate.post.mjs.map
