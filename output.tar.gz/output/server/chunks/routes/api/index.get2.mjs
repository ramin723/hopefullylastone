import { c as defineEventHandler, e as createError } from '../../_/nitro.mjs';
import { prisma } from '../../_/db.mjs';
import { r as requireAuth } from '../../_/auth.mjs';
import { l as logger } from '../../_/logger.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const index_get = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const vendors = await prisma.vendor.findMany({
      select: {
        id: true,
        storeName: true
      },
      orderBy: {
        storeName: "asc"
      }
    });
    logger.info({ count: vendors.length }, "[ADMIN VENDORS API] Vendors retrieved");
    return {
      items: vendors.map((v) => ({
        id: v.id,
        name: v.storeName
      }))
    };
  } catch (error) {
    logger.error({ err: error }, "[ADMIN VENDORS API] Error");
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while retrieving vendors"
    });
  }
});

export { index_get as default };
//# sourceMappingURL=index.get2.mjs.map
