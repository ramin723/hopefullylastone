import { c as defineEventHandler, r as readBody, e as createError } from '../../_/nitro.mjs';
import { prisma } from '../../_/db.mjs';
import { r as requireAuth } from '../../_/auth.mjs';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import { d as decimalToNumber } from '../../_/decimal.mjs';
import { l as logger } from '../../_/logger.mjs';
import { Prisma } from 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const CreateSettlementSchema = z.object({
  vendorId: z.number().int().positive(),
  mechanicId: z.number().int().positive().optional(),
  from: z.string().min(10),
  // YYYY-MM-DD
  to: z.string().min(10)
}).refine((v) => new Date(v.to) >= new Date(v.from), {
  message: "to must be >= from",
  path: ["to"]
});

const index_post = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["ADMIN"]);
    const body = await readBody(event);
    const parsed = CreateSettlementSchema.safeParse(body);
    if (!parsed.success) {
      throw createError({
        statusCode: 400,
        statusMessage: parsed.error.issues.map((i) => i.message).join(", ")
      });
    }
    const { vendorId, mechanicId, from, to } = parsed.data;
    const vendor = await prisma.vendor.findUnique({
      where: { id: vendorId },
      select: { id: true, storeName: true }
    });
    if (!vendor) {
      throw createError({ statusCode: 404, statusMessage: "Vendor not found" });
    }
    const fromDate = new Date(from);
    const toDate = new Date(to);
    fromDate.setHours(0, 0, 0, 0);
    toDate.setHours(23, 59, 59, 999);
    const excludedIds = (await prisma.settlementItem.findMany({ select: { transactionId: true } })).map((item) => item.transactionId);
    const txs = await prisma.transaction.findMany({
      where: {
        vendorId,
        status: "PENDING",
        createdAt: { gte: fromDate, lte: toDate },
        id: { notIn: excludedIds },
        ...mechanicId ? { mechanicId } : {}
      },
      include: { commission: true }
    });
    if (!txs.length) {
      return {
        created: false,
        message: "No pending transactions found in the specified date range",
        count: 0,
        vendorName: vendor.storeName
      };
    }
    const totalAmountEligible = txs.reduce((sum, t) => {
      return sum + decimalToNumber(t.amountEligible);
    }, 0);
    const totalMechanicAmount = txs.reduce((sum, t) => {
      var _a;
      return sum + decimalToNumber((_a = t.commission) == null ? void 0 : _a.mechanicAmount);
    }, 0);
    const totalPlatformAmount = txs.reduce((sum, t) => {
      var _a;
      return sum + decimalToNumber((_a = t.commission) == null ? void 0 : _a.platformAmount);
    }, 0);
    const result = await prisma.$transaction(async (tx) => {
      const settlement = await tx.settlement.create({
        data: {
          vendorId,
          periodFrom: fromDate,
          periodTo: toDate,
          totalAmountEligible,
          totalMechanicAmount,
          totalPlatformAmount,
          status: "OPEN",
          items: {
            create: txs.map((t) => {
              var _a, _b, _c, _d;
              return {
                transactionId: t.id,
                mechanicAmount: (_b = (_a = t.commission) == null ? void 0 : _a.mechanicAmount) != null ? _b : new Prisma.Decimal(0),
                platformAmount: (_d = (_c = t.commission) == null ? void 0 : _c.platformAmount) != null ? _d : new Prisma.Decimal(0)
              };
            })
          }
        },
        include: {
          vendor: { select: { storeName: true } }
        }
      });
      return settlement;
    });
    logger.info({ id: result.id, vendor: vendor.storeName, count: txs.length }, "Settlement created successfully");
    return {
      created: true,
      settlementId: result.id,
      vendorId,
      vendorName: result.vendor.storeName,
      periodFrom: result.periodFrom,
      periodTo: result.periodTo,
      totals: {
        eligible: totalAmountEligible,
        mechanic: totalMechanicAmount,
        platform: totalPlatformAmount
      },
      items: txs.map((t) => {
        var _a, _b;
        return {
          id: t.id,
          createdAt: t.createdAt,
          mechanicId: t.mechanicId,
          amountEligible: decimalToNumber(t.amountEligible),
          mechanicAmount: decimalToNumber((_a = t.commission) == null ? void 0 : _a.mechanicAmount),
          platformAmount: decimalToNumber((_b = t.commission) == null ? void 0 : _b.platformAmount)
        };
      }),
      count: txs.length,
      message: `Settlement created successfully for ${vendor.storeName}`
    };
  } catch (error) {
    logger.error({ err: error }, "Error creating settlement");
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while creating settlement"
    });
  }
});

export { index_post as default };
//# sourceMappingURL=index.post2.mjs.map
