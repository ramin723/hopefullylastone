import { c as defineEventHandler, e as createError, r as readBody } from '../../../../_/nitro.mjs';
import { prisma } from '../../../../_/db.mjs';
import { r as requireAuth } from '../../../../_/auth.mjs';
import { c as createRequestLogger } from '../../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const UpdateProfileSchema = z.object({
  fullName: z.string().min(1, "\u0646\u0627\u0645 \u06A9\u0627\u0645\u0644 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A").max(100, "\u0646\u0627\u0645 \u06A9\u0627\u0645\u0644 \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0628\u06CC\u0634 \u0627\u0632 100 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F"),
  storeName: z.string().max(100, "\u0646\u0627\u0645 \u0641\u0631\u0648\u0634\u06AF\u0627\u0647 \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0628\u06CC\u0634 \u0627\u0632 100 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional(),
  city: z.string().max(50, "\u0634\u0647\u0631 \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0628\u06CC\u0634 \u0627\u0632 50 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional(),
  specialties: z.string().max(200, "\u062A\u062E\u0635\u0635\u200C\u0647\u0627 \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0628\u06CC\u0634 \u0627\u0632 200 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional(),
  addressLine: z.string().max(200, "\u0622\u062F\u0631\u0633 \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0628\u06CC\u0634 \u0627\u0632 200 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional(),
  postalCode: z.string().max(10, "\u06A9\u062F \u067E\u0633\u062A\u06CC \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0628\u06CC\u0634 \u0627\u0632 10 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional(),
  province: z.string().max(50, "\u0627\u0633\u062A\u0627\u0646 \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0628\u06CC\u0634 \u0627\u0632 50 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").optional()
});
const profile = defineEventHandler(async (event) => {
  var _a;
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  try {
    const auth = await requireAuth(event, ["MECHANIC", "VENDOR", "ADMIN"]);
    logger.info("Profile request", { userId: auth.id, role: auth.role });
    if (event.method === "GET") {
      const user = await prisma.user.findUnique({
        where: { id: auth.id },
        select: {
          id: true,
          fullName: true,
          phone: true,
          role: true,
          createdAt: true,
          Mechanic: {
            select: {
              id: true,
              code: true,
              city: true,
              specialties: true,
              tier: true,
              qrActive: true
            }
          },
          Vendor: {
            select: {
              id: true,
              storeName: true,
              city: true,
              addressLine: true,
              postalCode: true,
              province: true,
              percentDefault: true,
              status: true,
              isActive: true
            }
          }
        }
      });
      if (!user) {
        logger.error("User not found", { userId: auth.id });
        throw createError({
          statusCode: 404,
          statusMessage: "User not found"
        });
      }
      let profile = null;
      if (user.role === "MECHANIC" && user.Mechanic) {
        profile = user.Mechanic;
      } else if (user.role === "VENDOR" && user.Vendor) {
        profile = user.Vendor;
      }
      logger.info("Profile retrieved successfully", { userId: auth.id });
      return {
        user: {
          id: user.id,
          fullName: user.fullName,
          phone: user.phone,
          role: user.role,
          createdAt: user.createdAt
        },
        profile
      };
    } else if (event.method === "PATCH") {
      const body = await readBody(event);
      const validation = UpdateProfileSchema.safeParse(body);
      if (!validation.success) {
        logger.error("Profile update validation failed", {
          errors: validation.error.issues.map((e) => e.message)
        });
        throw createError({
          statusCode: 400,
          statusMessage: ((_a = validation.error.issues[0]) == null ? void 0 : _a.message) || "Invalid input"
        });
      }
      const updateData = validation.data;
      const updatedUser = await prisma.user.update({
        where: { id: auth.id },
        data: {
          fullName: updateData.fullName
        },
        select: {
          id: true,
          fullName: true,
          phone: true,
          role: true
        }
      });
      if (auth.role === "VENDOR") {
        await prisma.vendor.update({
          where: { userId: auth.id },
          data: {
            storeName: updateData.storeName || void 0,
            city: updateData.city || void 0,
            addressLine: updateData.addressLine || void 0,
            postalCode: updateData.postalCode || void 0,
            province: updateData.province || void 0
          }
        });
      } else if (auth.role === "MECHANIC") {
        await prisma.mechanic.update({
          where: { userId: auth.id },
          data: {
            city: updateData.city || void 0,
            specialties: updateData.specialties || void 0
          }
        });
      }
      logger.info("Profile updated successfully", { userId: auth.id });
      return {
        user: updatedUser,
        message: "Profile updated successfully"
      };
    } else {
      throw createError({
        statusCode: 405,
        statusMessage: "Method not allowed"
      });
    }
  } catch (error) {
    logger.error("Profile operation failed", {
      error: error.message,
      statusCode: error.statusCode
    });
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error"
    });
  }
});

export { profile as default };
//# sourceMappingURL=profile.mjs.map
