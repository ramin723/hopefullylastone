import { c as defineEventHandler, r as readBody, e as createError } from '../../../../_/nitro.mjs';
import { prisma } from '../../../../_/db.mjs';
import { r as requireAuth } from '../../../../_/auth.mjs';
import { c as createRequestLogger } from '../../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import bcrypt from 'file://D:/hamkari/node_modules/bcryptjs/index.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const ChangePasswordSchema = z.object({
  currentPassword: z.string().min(1, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0641\u0639\u0644\u06CC \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A"),
  newPassword: z.string().min(6, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 6 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").max(100, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0628\u06CC\u0634 \u0627\u0632 100 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F")
});
const changePassword_post = defineEventHandler(async (event) => {
  var _a;
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  try {
    const auth = await requireAuth(event, ["MECHANIC", "VENDOR", "ADMIN"]);
    logger.info("Change password request", { userId: auth.id });
    const body = await readBody(event);
    const validation = ChangePasswordSchema.safeParse(body);
    if (!validation.success) {
      logger.error("Change password validation failed", {
        errors: validation.error.issues.map((e) => e.message)
      });
      throw createError({
        statusCode: 400,
        statusMessage: ((_a = validation.error.issues[0]) == null ? void 0 : _a.message) || "Invalid input"
      });
    }
    const { currentPassword, newPassword } = validation.data;
    if (currentPassword === newPassword) {
      logger.warn("New password same as current", { userId: auth.id });
      throw createError({
        statusCode: 400,
        statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0628\u0627\u06CC\u062F \u0628\u0627 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0641\u0639\u0644\u06CC \u0645\u062A\u0641\u0627\u0648\u062A \u0628\u0627\u0634\u062F"
      });
    }
    const user = await prisma.user.findUnique({
      where: { id: auth.id },
      select: {
        id: true,
        passwordHash: true,
        fullName: true
      }
    });
    if (!user) {
      logger.error("User not found", { userId: auth.id });
      throw createError({
        statusCode: 404,
        statusMessage: "User not found"
      });
    }
    const isCurrentPasswordValid = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!isCurrentPasswordValid) {
      logger.warn("Invalid current password", { userId: auth.id });
      throw createError({
        statusCode: 400,
        statusMessage: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0641\u0639\u0644\u06CC \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A"
      });
    }
    const newPasswordHash = await bcrypt.hash(newPassword, 12);
    await prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: auth.id },
        data: {
          passwordHash: newPasswordHash,
          mustChangePassword: false
          // اگر کاربر مجبور به تغییر رمز بود، این فلگ را بردار
        }
      });
      await tx.refreshToken.updateMany({
        where: {
          userId: auth.id,
          revokedAt: null
        },
        data: {
          revokedAt: /* @__PURE__ */ new Date()
        }
      });
    });
    logger.info("Password changed successfully", { userId: auth.id });
    return {
      message: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062A\u063A\u06CC\u06CC\u0631 \u06A9\u0631\u062F",
      success: true
    };
  } catch (error) {
    logger.error("Change password failed", {
      error: error.message,
      statusCode: error.statusCode
    });
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error"
    });
  }
});

export { changePassword_post as default };
//# sourceMappingURL=change-password.post.mjs.map
