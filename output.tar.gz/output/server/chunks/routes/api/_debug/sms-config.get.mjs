import { c as defineEventHandler, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';

const smsConfig_get = defineEventHandler(async (event) => {
  await requireAuth(event, ["ADMIN"]);
  const config = useRuntimeConfig();
  const { smsProvider, kavenegar } = config;
  return {
    ok: true,
    provider: smsProvider,
    kavenegar: {
      hasApiKey: !!(kavenegar == null ? void 0 : kavenegar.apiKey),
      templateOtp: (kavenegar == null ? void 0 : kavenegar.templateOtp) || "otp-login",
      templateInvite: (kavenegar == null ? void 0 : kavenegar.templateInvite) || "invite-code",
      devBypass: (kavenegar == null ? void 0 : kavenegar.devBypass) || false
    },
    envNodeEnv: "production"
  };
});

export { smsConfig_get as default };
//# sourceMappingURL=sms-config.get.mjs.map
