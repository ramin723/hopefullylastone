import { c as defineEventHandler, j as getHeader, e as createError, r as readBody, u as useRuntimeConfig, n as getRequestURL } from '../../_/nitro.mjs';
import { prisma } from '../../_/db.mjs';
import { r as requireAuth } from '../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../_/rateLimiter.mjs';
import { l as logger } from '../../_/logger.mjs';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import { b as generateOrderCode } from '../../_/ids.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const CreateOrderSchema = z.object({
  customerPhone: z.string().min(10, "\u0634\u0645\u0627\u0631\u0647 \u062A\u0644\u0641\u0646 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 10 \u0631\u0642\u0645 \u0628\u0627\u0634\u062F"),
  note: z.string().optional(),
  items: z.array(z.object({
    title: z.string().min(1, "\u0639\u0646\u0648\u0627\u0646 \u0622\u06CC\u062A\u0645 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A"),
    quantity: z.number().int().min(1, "\u062A\u0639\u062F\u0627\u062F \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 1 \u0628\u0627\u0634\u062F").default(1),
    note: z.string().optional()
  })).min(1, "\u062D\u062F\u0627\u0642\u0644 \u06CC\u06A9 \u0622\u06CC\u062A\u0645 \u0628\u0627\u06CC\u062F \u0648\u0627\u0631\u062F \u0634\u0648\u062F").max(50, "\u062D\u062F\u0627\u06A9\u062B\u0631 50 \u0622\u06CC\u062A\u0645 \u0645\u062C\u0627\u0632 \u0627\u0633\u062A")
});
z.object({
  code: z.string().min(12, "\u06A9\u062F \u0633\u0641\u0627\u0631\u0634 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A").max(12, "\u06A9\u062F \u0633\u0641\u0627\u0631\u0634 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A")
});

const index_post = defineEventHandler(async (event) => {
  var _a;
  const requestId = crypto.randomUUID();
  try {
    logger.info({
      requestId,
      endpoint: "POST /api/orders",
      userAgent: getHeader(event, "user-agent"),
      ip: getClientIP(event)
    }, "[ORDERS API] Request started");
    const auth = await requireAuth(event, ["MECHANIC"]);
    logger.info({
      requestId,
      userId: auth.id,
      role: auth.role
    }, "[ORDERS API] Authentication successful");
    logger.info({
      requestId,
      userId: auth.id,
      role: auth.role
    }, "[ORDERS API] Entering rate-limit check");
    const ip = getClientIP(event);
    const rateKey = `orders.create:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 5 * 60 * 1e3,
      // 5 minutes
      max: 30
    });
    logger.info({
      requestId,
      userId: auth.id,
      role: auth.role,
      allowed: rateLimit.allowed,
      remaining: rateLimit.remaining,
      resetAt: rateLimit.resetAt
    }, "[ORDERS API] Rate-limit check completed");
    if (!rateLimit.allowed) {
      logger.warn({
        requestId,
        userId: auth.id,
        role: auth.role,
        remaining: rateLimit.remaining,
        resetAt: rateLimit.resetAt
      }, "[ORDERS API] Rate limit exceeded");
      throw createError({
        statusCode: 429,
        statusMessage: "Too many order creation requests"
      });
    }
    const body = await readBody(event);
    const validation = CreateOrderSchema.safeParse(body);
    if (!validation.success) {
      throw createError({
        statusCode: 400,
        statusMessage: validation.error.issues.map((i) => i.message).join(", ")
      });
    }
    const { customerPhone, note, items } = validation.data;
    let orderCode;
    let attempts = 0;
    const maxAttempts = 10;
    do {
      orderCode = generateOrderCode();
      attempts++;
      if (attempts > maxAttempts) {
        throw createError({
          statusCode: 500,
          statusMessage: "Failed to generate unique order code"
        });
      }
    } while (await prisma.order.findUnique({ where: { code: orderCode } }));
    const mechanic = await prisma.mechanic.findUnique({
      where: { userId: auth.id },
      select: { id: true }
    });
    if (!mechanic) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mechanic profile not found"
      });
    }
    const order = await prisma.$transaction(async (tx) => {
      const newOrder = await tx.order.create({
        data: {
          code: orderCode,
          mechanicId: mechanic.id,
          customerPhone: customerPhone.trim(),
          note: (note == null ? void 0 : note.trim()) || null,
          status: "PENDING"
        }
      });
      await tx.orderItem.createMany({
        data: items.map((item) => {
          var _a2;
          return {
            orderId: newOrder.id,
            title: item.title.trim(),
            quantity: item.quantity,
            note: ((_a2 = item.note) == null ? void 0 : _a2.trim()) || null
          };
        })
      });
      return newOrder;
    });
    const config = useRuntimeConfig();
    const baseUrl = config.public.appBaseURL || getRequestURL(event).origin;
    const shareUrl = `${baseUrl}/o/${orderCode}`;
    logger.info({
      orderId: order.id,
      orderCode,
      mechanicId: mechanic.id,
      customerPhone: `***${customerPhone.slice(-4)}`,
      itemCount: items.length
    }, "[ORDERS API] New order created");
    return {
      ok: true,
      order: {
        id: order.id,
        code: order.code,
        shareUrl
      }
    };
  } catch (error) {
    if (error.statusCode === 401) {
      logger.warn({
        requestId,
        message: "Unauthorized access attempt"
      }, "[ORDERS API] Authentication failed");
    } else if (error.statusCode === 403) {
      logger.warn({
        requestId,
        message: "Forbidden access - Invalid CSRF token or insufficient permissions"
      }, "[ORDERS API] Authorization failed");
    } else if (error.statusCode === 429) {
      logger.warn({
        requestId,
        message: "Rate limit exceeded"
      }, "[ORDERS API] Rate limit exceeded");
    } else if (error.statusCode === 422) {
      logger.warn({
        requestId,
        message: "Validation error",
        validationErrors: ((_a = error.data) == null ? void 0 : _a.message) || "Invalid request data"
      }, "[ORDERS API] Validation failed");
    } else if (error.statusCode) {
      logger.error({
        requestId,
        statusCode: error.statusCode,
        message: error.statusMessage
      }, "[ORDERS API] Client error");
    } else {
      logger.error({
        requestId,
        err: error
      }, "[ORDERS API] Internal server error");
    }
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while creating order"
    });
  }
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
