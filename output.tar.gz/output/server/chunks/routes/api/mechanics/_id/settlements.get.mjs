import { c as defineEventHandler, f as getRouterParam, e as createError, g as getQuery } from '../../../../_/nitro.mjs';
import { prisma } from '../../../../_/db.mjs';
import { r as requireAuth } from '../../../../_/auth.mjs';
import { d as decimalToNumber } from '../../../../_/decimal.mjs';
import { l as logger } from '../../../../_/logger.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const settlements_get = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["MECHANIC", "ADMIN"]);
    const mechanicIdParam = Number(getRouterParam(event, "id"));
    if (!mechanicIdParam || isNaN(mechanicIdParam)) {
      throw createError({ statusCode: 400, statusMessage: "Invalid mechanic ID" });
    }
    if (auth.role === "MECHANIC") {
      const mechanic = await prisma.mechanic.findUnique({
        where: { userId: auth.id },
        select: { id: true }
      });
      if (!mechanic || mechanic.id !== mechanicIdParam) {
        throw createError({ statusCode: 403, statusMessage: "Access denied: You can only view your own settlements" });
      }
    }
    const mechanicExists = await prisma.mechanic.findUnique({
      where: { id: mechanicIdParam },
      include: { user: { select: { fullName: true } } }
    });
    if (!mechanicExists) {
      throw createError({ statusCode: 404, statusMessage: "Mechanic not found" });
    }
    const q = getQuery(event);
    const where = {
      items: {
        some: {
          transaction: { mechanicId: mechanicIdParam }
        }
      }
    };
    if (q.status && typeof q.status === "string" && ["OPEN", "PAID"].includes(q.status)) {
      where.status = q.status;
    }
    if (q.from && typeof q.from === "string") {
      const fromDate = new Date(q.from);
      if (!isNaN(fromDate.getTime())) {
        where.periodFrom = { gte: fromDate };
      }
    }
    if (q.to && typeof q.to === "string") {
      const toDate = new Date(q.to);
      if (!isNaN(toDate.getTime())) {
        toDate.setHours(23, 59, 59, 999);
        where.periodTo = { lte: toDate };
      }
    }
    const settlements = await prisma.settlement.findMany({
      where,
      orderBy: { id: "desc" },
      include: {
        vendor: { select: { storeName: true, city: true } },
        items: {
          where: { transaction: { mechanicId: mechanicIdParam } },
          include: {
            transaction: {
              select: {
                id: true,
                createdAt: true,
                mechanicId: true,
                amountEligible: true
              }
            }
          }
        },
        _count: {
          select: {
            items: {
              where: { transaction: { mechanicId: mechanicIdParam } }
            }
          }
        }
      }
    });
    const settlementsWithTotals = settlements.map((s) => {
      const mechanicItems = s.items.filter(
        (item) => item.transaction.mechanicId === mechanicIdParam
      );
      const totals = {
        eligible: mechanicItems.reduce(
          (sum, item) => sum + decimalToNumber(item.transaction.amountEligible),
          0
        ),
        mechanic: mechanicItems.reduce(
          (sum, item) => sum + decimalToNumber(item.mechanicAmount),
          0
        ),
        platform: mechanicItems.reduce(
          (sum, item) => sum + decimalToNumber(item.platformAmount),
          0
        )
      };
      return {
        id: s.id,
        vendorId: s.vendorId,
        vendorName: s.vendor.storeName,
        vendorCity: s.vendor.city,
        periodFrom: s.periodFrom,
        periodTo: s.periodTo,
        totals,
        status: s.status,
        createdAt: s.createdAt,
        paidAt: s.paidAt,
        itemCount: s._count.items
      };
    });
    logger.info({ mechanicId: mechanicIdParam, count: settlementsWithTotals.length }, "[MECHANIC SETTLEMENTS API] Retrieved");
    return settlementsWithTotals;
  } catch (error) {
    const mechanicIdParam = Number(getRouterParam(event, "id"));
    logger.error({ err: error, mechanicId: mechanicIdParam }, "[MECHANIC SETTLEMENTS API] Error");
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while retrieving mechanic settlements"
    });
  }
});

export { settlements_get as default };
//# sourceMappingURL=settlements.get.mjs.map
