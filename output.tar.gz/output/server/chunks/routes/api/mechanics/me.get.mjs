import { c as defineEventHandler, g as getQuery, e as createError } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';

const me_get = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["MECHANIC", "ADMIN"]);
    if (auth.role === "ADMIN") {
      const q = getQuery(event);
      if (!q.userId || typeof q.userId !== "string") {
        throw createError({
          statusCode: 400,
          statusMessage: "Admin must provide userId query parameter"
        });
      }
      const mechanic2 = await prisma.mechanic.findUnique({
        where: { id: Number(q.userId) },
        include: { user: { select: { fullName: true } } }
      });
      if (!mechanic2) {
        throw createError({ statusCode: 404, statusMessage: "Mechanic not found" });
      }
      return {
        id: mechanic2.id,
        code: mechanic2.code,
        name: mechanic2.user.fullName,
        tier: mechanic2.tier,
        qrActive: mechanic2.qrActive,
        createdAt: mechanic2.createdAt
      };
    }
    const mechanic = await prisma.mechanic.findUnique({
      where: { userId: auth.id },
      include: { user: { select: { fullName: true } } }
    });
    if (!mechanic) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mechanic profile not found"
      });
    }
    return {
      id: mechanic.id,
      code: mechanic.code,
      name: mechanic.user.fullName,
      tier: mechanic.tier,
      qrActive: mechanic.qrActive,
      createdAt: mechanic.createdAt
    };
  } catch (error) {
    console.error("[MECHANIC ME API] Error:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while retrieving mechanic profile"
    });
  }
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
