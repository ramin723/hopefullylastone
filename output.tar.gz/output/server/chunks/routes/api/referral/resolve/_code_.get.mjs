import { c as defineEventHandler, k as getRequestIP, e as createError, f as getRouterParam } from '../../../../_/nitro.mjs';
import { prisma } from '../../../../_/db.mjs';
import { r as requireAuth } from '../../../../_/auth.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';

const LOCAL_BUCKET = /* @__PURE__ */ new Map();
const _code__get = defineEventHandler(async (event) => {
  const auth = await requireAuth(event, ["VENDOR", "ADMIN"]);
  const ip = getRequestIP(event) || "unknown";
  const rateKey = `${auth.id}|${ip}|referral.resolve`;
  const now = Date.now();
  const windowMs = 6e4;
  const limit = 10;
  const entries = LOCAL_BUCKET.get(rateKey) || [];
  while (entries.length && now - entries[0].ts > windowMs) entries.shift();
  if (entries.length >= limit) {
    throw createError({ statusCode: 429, statusMessage: "Too many requests" });
  }
  entries.push({ ts: now });
  LOCAL_BUCKET.set(rateKey, entries);
  const code = getRouterParam(event, "code");
  if (!code) throw createError({ statusCode: 400, statusMessage: "mechanic code is required" });
  const mech = await prisma.mechanic.findUnique({
    where: { code },
    select: { id: true, code: true, qrActive: true }
  });
  const ok = !!(mech && mech.qrActive);
  code.substring(0, 2);
  if (ok) {
    return {
      ok: true,
      mechanicId: mech.id,
      mechanicCode: mech.code
    };
  } else {
    return {
      ok: false,
      mechanicId: null,
      mechanicCode: null
    };
  }
});

export { _code__get as default };
//# sourceMappingURL=_code_.get.mjs.map
