import { c as defineEventHandler, e as createError, o as getRequestHeader, r as readBody } from '../../_/nitro.mjs';
import { prisma } from '../../_/db.mjs';
import { r as requireAuth } from '../../_/auth.mjs';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import { Prisma } from 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import { l as logger } from '../../_/logger.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const CreateTxSchema = z.object({
  mechanicCode: z.string().min(3, "mechanicCode required"),
  customerPhone: z.string().min(5, "customerPhone too short"),
  amountTotal: z.number().int().positive("amountTotal must be > 0"),
  amountEligible: z.number().int().positive("amountEligible must be > 0"),
  note: z.string().optional(),
  orderCode: z.string().optional()
  // Optional order code for consuming orders
}).refine((d) => d.amountEligible <= d.amountTotal, {
  message: "amountEligible must be <= amountTotal",
  path: ["amountEligible"]
});

function computeCommission(amountEligible, rateMechanic = 0.03, ratePlatform = 0.02) {
  const amt = new Prisma.Decimal(amountEligible);
  const mechanicAmount = amt.mul(new Prisma.Decimal(rateMechanic)).toDecimalPlaces(0);
  const platformAmount = amt.mul(new Prisma.Decimal(ratePlatform)).toDecimalPlaces(0);
  return { mechanicAmount, platformAmount };
}

const index_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e;
  try {
    const auth = await requireAuth(event, ["VENDOR"]);
    const vendor = await prisma.vendor.findUnique({ where: { userId: auth.id } });
    if (!vendor || vendor.status !== "ACTIVE") {
      throw createError({ statusCode: 403, statusMessage: "Vendor not active" });
    }
    const idem = (_a = getRequestHeader(event, "x-idempotency-key")) == null ? void 0 : _a.trim();
    if (idem) {
      const exists = await prisma.transaction.findFirst({
        where: { idempotencyKey: idem, vendorId: vendor.id }
      });
      if (exists) {
        return { id: exists.id, idempotent: true };
      }
    }
    const body = await readBody(event);
    const parsed = CreateTxSchema.safeParse(body);
    if (!parsed.success) {
      throw createError({ statusCode: 400, statusMessage: parsed.error.issues.map((i) => i.message).join(", ") });
    }
    const { mechanicCode, customerPhone, amountTotal, amountEligible, note, orderCode } = parsed.data;
    const mechanic = await prisma.mechanic.findUnique({
      where: { code: mechanicCode },
      include: { user: true }
    });
    if (!mechanic || !mechanic.qrActive) {
      throw createError({ statusCode: 404, statusMessage: "mechanic not found or inactive" });
    }
    let order = null;
    if (orderCode) {
      order = await prisma.order.findUnique({
        where: { code: orderCode },
        select: { id: true, status: true, mechanicId: true }
      });
      if (!order) {
        throw createError({ statusCode: 404, statusMessage: "Order not found" });
      }
      if (order.status !== "PENDING") {
        throw createError({ statusCode: 409, statusMessage: "Order already consumed or invalid" });
      }
      if (order.mechanicId !== mechanic.id) {
        throw createError({ statusCode: 400, statusMessage: "Order does not belong to this mechanic" });
      }
    }
    const { mechanicAmount, platformAmount } = computeCommission(amountEligible, 0.03, 0.02);
    const tx = await prisma.$transaction(async (prismaTx) => {
      const transaction = await prismaTx.transaction.create({
        data: {
          mechanicId: mechanic.id,
          vendorId: vendor.id,
          customerPhone,
          amountTotal,
          amountEligible,
          note,
          status: "PENDING",
          idempotencyKey: idem || null,
          commission: {
            create: {
              rateMechanic: 0.03,
              ratePlatform: 0.02,
              mechanicAmount,
              platformAmount
            }
          }
        },
        include: { commission: true }
      });
      if (order) {
        await prismaTx.order.update({
          where: { id: order.id },
          data: {
            status: "CONSUMED",
            consumedAt: /* @__PURE__ */ new Date(),
            consumedByVendorId: vendor.id
          }
        });
        logger.info({
          orderId: order.id,
          orderCode,
          transactionId: transaction.id,
          vendorId: vendor.id
        }, "[TRANSACTIONS API] Order consumed during transaction creation");
      }
      return transaction;
    });
    return {
      id: tx.id,
      status: tx.status,
      mechanic: { id: mechanic.id, name: mechanic.user.fullName, code: mechanic.code },
      vendor: { id: vendor.id, name: vendor.storeName },
      amounts: {
        total: tx.amountTotal,
        eligible: tx.amountTotal,
        commission: {
          mechanic: (_c = (_b = tx.commission) == null ? void 0 : _b.mechanicAmount) != null ? _c : mechanicAmount,
          platform: (_e = (_d = tx.commission) == null ? void 0 : _d.platformAmount) != null ? _e : platformAmount
        }
      },
      createdAt: tx.createdAt
    };
  } catch (error) {
    console.error("[TRANSACTIONS API] Error:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while creating transaction"
    });
  }
});

export { index_post as default };
//# sourceMappingURL=index.post3.mjs.map
