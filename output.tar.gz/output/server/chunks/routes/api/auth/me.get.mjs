import { c as defineEventHandler, j as getHeader, l as getCookie, e as createError } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { i as isTokenExpired, v as verifyAccessToken } from '../../../_/tokens.mjs';
import { c as createRequestLogger } from '../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const me_get = defineEventHandler(async (event) => {
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Me endpoint called");
  let token = getHeader(event, "authorization");
  if (token && token.startsWith("Bearer ")) {
    token = token.slice(7);
  } else {
    token = getCookie(event, "at");
  }
  if (!token) {
    logger.error("No token found in header or cookie");
    throw createError({ statusCode: 401, statusMessage: "No token provided" });
  }
  if (isTokenExpired(token)) {
    logger.info("Access token expired, attempting refresh");
    try {
      const refreshResponse = await $fetch("/api/auth/refresh", {
        method: "POST",
        headers: {
          "Cookie": getHeader(event, "cookie") || ""
        }
      });
      const newToken = getCookie(event, "at");
      if (newToken) {
        token = newToken;
        logger.info("Token refreshed successfully");
      } else {
        logger.error("Failed to get new token after refresh");
        throw createError({ statusCode: 401, statusMessage: "Token refresh failed" });
      }
    } catch (refreshError) {
      logger.error("Token refresh failed", { error: (refreshError == null ? void 0 : refreshError.message) || "Unknown error" });
      console.error("[ME API] Token refresh failed:", refreshError);
      throw createError({ statusCode: 401, statusMessage: "Token refresh failed" });
    }
  }
  const payload = verifyAccessToken(token);
  if (!payload) {
    logger.error("Invalid token");
    throw createError({ statusCode: 401, statusMessage: "Invalid token" });
  }
  const user = await prisma.user.findUnique({
    where: { id: payload.userId },
    select: { id: true, role: true, fullName: true, phone: true, mustChangePassword: true }
  });
  if (!user) {
    logger.error("User not found", { userId: payload.userId });
    throw createError({ statusCode: 401, statusMessage: "User not found" });
  }
  logger.info("User authenticated successfully", { userId: user.id, role: user.role });
  return {
    user: {
      id: user.id,
      role: user.role,
      fullName: user.fullName,
      phone: user.phone,
      mustChangePassword: user.mustChangePassword
    }
  };
});

export { me_get as default };
//# sourceMappingURL=me.get.mjs.map
