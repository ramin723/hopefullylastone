import { c as defineEventHandler, r as readBody, e as createError, h as appendResponseHeader } from '../../../../_/nitro.mjs';
import { prisma } from '../../../../_/db.mjs';
import { c as createRequestLogger } from '../../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { g as getClientIP, h as hashPhone, r as rateLimitComposite, m as maskPhone } from '../../../../_/rateLimiter.mjs';
import { R as RequestOtpSchema } from '../../../../_/otp2.mjs';
import { n as normalizePhone, g as generateNumericCode, h as hashCode } from '../../../../_/otp.mjs';
import { s as sendOtpViaVerifyLookup } from '../../../../_/sms.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';
import 'file://D:/hamkari/node_modules/zod/index.js';
import 'file://D:/hamkari/node_modules/kavenegar/kavenegar.js';

const request_post = defineEventHandler(async (event) => {
  var _a;
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("OTP request started");
  const body = await readBody(event);
  const validation = RequestOtpSchema.safeParse(body);
  if (!validation.success) {
    logger.error("OTP request validation failed", {
      errors: validation.error.issues.map((e) => e.message)
    });
    throw createError({
      statusCode: 400,
      statusMessage: ((_a = validation.error.issues[0]) == null ? void 0 : _a.message) || "Invalid input"
    });
  }
  const { phone, purpose } = validation.data;
  const normalizedPhone = normalizePhone(phone);
  const ip = getClientIP(event);
  const phoneHash = hashPhone(normalizedPhone);
  const key = `${ip}:${phoneHash}:${purpose}`;
  const { allowed, remaining, resetAt } = rateLimitComposite({
    key,
    windowMs: 10 * 60 * 1e3,
    // 10 minutes
    max: 5
    // 5 requests per 10 minutes
  });
  if (!allowed) {
    const retryAfterSec = Math.max(1, Math.ceil((resetAt - Date.now()) / 1e3));
    appendResponseHeader(event, "Retry-After", retryAfterSec);
    logger.warn("OTP request rate-limited", {
      requestId,
      phone: maskPhone(normalizedPhone),
      remaining,
      resetAt
    });
    throw createError({
      statusCode: 429,
      statusMessage: "Too Many Requests",
      message: "Too many OTP requests. Please try again later."
    });
  }
  logger.info("OTP request allowed", {
    requestId,
    phone: maskPhone(normalizedPhone),
    remaining,
    resetAt
  });
  try {
    const existingOtp = await prisma.otpCode.findFirst({
      where: {
        phone: normalizedPhone,
        purpose,
        isUsed: false,
        expiresAt: { gt: /* @__PURE__ */ new Date() }
      },
      orderBy: { createdAt: "desc" }
    });
    if (existingOtp) {
      logger.info("Valid OTP already exists, not generating new one", {
        requestId,
        phone: maskPhone(normalizedPhone),
        expiresAt: existingOtp.expiresAt
      });
      return {
        ok: true,
        message: "\u0627\u06AF\u0631 \u0634\u0645\u0627\u0631\u0647 \u0645\u0639\u062A\u0628\u0631 \u0628\u0627\u0634\u062F\u060C \u06A9\u062F \u0627\u0631\u0633\u0627\u0644 \u0634\u062F"
      };
    }
    const code = generateNumericCode(5);
    const codeHash = hashCode(code);
    const expiresAt = new Date(Date.now() + 4 * 60 * 1e3);
    await prisma.otpCode.create({
      data: {
        phone: normalizedPhone,
        codeHash,
        purpose,
        expiresAt,
        attempts: 0,
        isUsed: false
      }
    });
    try {
      await sendOtpViaVerifyLookup({ phone: normalizedPhone, code, template: "otp-login" });
      logger.info("OTP generated and sent successfully", {
        requestId,
        phone: maskPhone(normalizedPhone),
        expiresAt
      });
      return {
        ok: true,
        message: "\u06A9\u062F \u0628\u0647 \u0634\u0645\u0627\u0631\u0647 \u0627\u0631\u0633\u0627\u0644 \u0634\u062F"
      };
    } catch (smsError) {
      await prisma.otpCode.deleteMany({
        where: {
          phone: normalizedPhone,
          purpose,
          codeHash,
          isUsed: false
        }
      });
      logger.error("OTP SMS send failed, OTP deleted", {
        requestId,
        phone: maskPhone(normalizedPhone),
        error: smsError.message
      });
      throw smsError;
    }
  } catch (error) {
    logger.error("OTP request failed", {
      requestId,
      phone: maskPhone(normalizedPhone),
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      message: "Failed to process OTP request"
    });
  }
});

export { request_post as default };
//# sourceMappingURL=request.post.mjs.map
