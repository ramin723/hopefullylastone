import { c as defineEventHandler, h as appendResponseHeader, e as createError, r as readBody } from '../../../../_/nitro.mjs';
import { prisma } from '../../../../_/db.mjs';
import { c as createRequestLogger } from '../../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { g as getClientIP, r as rateLimitComposite, m as maskPhone } from '../../../../_/rateLimiter.mjs';
import { z } from 'file://D:/hamkari/node_modules/zod/index.js';
import { r as requireAuth } from '../../../../_/auth.mjs';
import bcrypt from 'file://D:/hamkari/node_modules/bcryptjs/index.js';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const SetInitialPasswordSchema = z.object({
  password: z.string().min(8, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 8 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").regex(/[a-zA-Z]/, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06CC\u06A9 \u062D\u0631\u0641 \u0627\u0646\u06AF\u0644\u06CC\u0633\u06CC \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F").regex(/\d/, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06CC\u06A9 \u0631\u0642\u0645 \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F").max(128, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634 \u0627\u0632 128 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F")
});
z.object({
  currentPassword: z.string().min(1, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0641\u0639\u0644\u06CC \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A"),
  newPassword: z.string().min(8, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 8 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F").regex(/[a-zA-Z]/, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06CC\u06A9 \u062D\u0631\u0641 \u0627\u0646\u06AF\u0644\u06CC\u0633\u06CC \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F").regex(/\d/, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06CC\u06A9 \u0631\u0642\u0645 \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F").max(128, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062C\u062F\u06CC\u062F \u0646\u0628\u0627\u06CC\u062F \u0628\u06CC\u0634 \u0627\u0632 128 \u06A9\u0627\u0631\u0627\u06A9\u062A\u0631 \u0628\u0627\u0634\u062F")
});

const setInitial_post = defineEventHandler(async (event) => {
  var _a;
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Set initial password request started");
  const user = await requireAuth(event);
  const ip = getClientIP(event);
  const rateKey = `set-initial-password:${ip}:${user.id}`;
  const { allowed, remaining, resetAt } = rateLimitComposite({
    key: rateKey,
    windowMs: 10 * 60 * 1e3,
    // 10 minutes
    max: 10
    // 10 requests per 10 minutes
  });
  if (!allowed) {
    const retryAfterSec = Math.max(1, Math.ceil((resetAt - Date.now()) / 1e3));
    appendResponseHeader(event, "Retry-After", retryAfterSec);
    logger.warn("Set initial password rate-limited", {
      requestId,
      userId: user.id,
      phone: maskPhone(user.phone || ""),
      remaining,
      resetAt
    });
    throw createError({
      statusCode: 429,
      statusMessage: "Too Many Requests",
      message: "\u062A\u0639\u062F\u0627\u062F \u062F\u0631\u062E\u0648\u0627\u0633\u062A\u200C\u0647\u0627\u06CC \u0634\u0645\u0627 \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 \u0627\u0633\u062A. \u0644\u0637\u0641\u0627\u064B \u0686\u0646\u062F \u062F\u0642\u06CC\u0642\u0647 \u0635\u0628\u0631 \u06A9\u0646\u06CC\u062F."
    });
  }
  const body = await readBody(event);
  const validation = SetInitialPasswordSchema.safeParse(body);
  if (!validation.success) {
    logger.error("Set initial password validation failed", {
      requestId,
      userId: user.id,
      errors: validation.error.issues.map((e) => e.message)
    });
    throw createError({
      statusCode: 400,
      statusMessage: ((_a = validation.error.issues[0]) == null ? void 0 : _a.message) || "Invalid input"
    });
  }
  const { password } = validation.data;
  logger.info("Set initial password request allowed", {
    requestId,
    userId: user.id,
    phone: maskPhone(user.phone || ""),
    remaining,
    resetAt
  });
  try {
    const fullUser = await prisma.user.findUnique({
      where: { id: user.id },
      select: {
        id: true,
        mustChangePassword: true,
        passwordHash: true
      }
    });
    if (!fullUser) {
      throw createError({
        statusCode: 404,
        statusMessage: "User not found"
      });
    }
    const hasPassword = fullUser.passwordHash && fullUser.passwordHash.length > 0;
    if (!fullUser.mustChangePassword || hasPassword) {
      logger.info("User tried to set initial password but already set", {
        requestId,
        userId: user.id,
        phone: maskPhone(user.phone || ""),
        mustChangePassword: fullUser.mustChangePassword,
        hasPassword
      });
      return {
        ok: true,
        message: "Password already set",
        already: true
      };
    }
    const passwordHash = await bcrypt.hash(password, 12);
    await prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: fullUser.id },
        data: {
          passwordHash,
          mustChangePassword: false
        }
      });
    });
    logger.info("Initial password set successfully", {
      requestId,
      userId: user.id,
      phone: maskPhone(user.phone || "")
    });
    return {
      ok: true,
      message: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u062B\u0628\u062A \u0634\u062F",
      already: false
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error("Set initial password failed", {
      requestId,
      userId: user.id,
      phone: maskPhone(user.phone || ""),
      error: error instanceof Error ? error.message : "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Internal Server Error",
      message: "\u062E\u0637\u0627 \u062F\u0631 \u062B\u0628\u062A \u0631\u0645\u0632 \u0639\u0628\u0648\u0631"
    });
  }
});

export { setInitial_post as default };
//# sourceMappingURL=set-initial.post.mjs.map
