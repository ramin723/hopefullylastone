import { c as defineEventHandler, i as setCookie, e as createError } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { c as createRequestLogger } from '../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const logout_post = defineEventHandler(async (event) => {
  var _a;
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("[AUTH] Logout attempt started", { requestId });
  try {
    const userId = (_a = event.context) == null ? void 0 : _a.authUserId;
    if (userId) {
      await prisma.refreshToken.deleteMany({
        where: { userId }
      });
      logger.info("[AUTH] Refresh tokens deleted for user", { requestId, userId });
    }
    const isProd = true;
    const cookieOpts = {
      httpOnly: true,
      sameSite: "lax",
      secure: isProd,
      path: "/",
      maxAge: 0
    };
    setCookie(event, "at", "", { ...cookieOpts, maxAge: 0 });
    setCookie(event, "rt", "", { ...cookieOpts, maxAge: 0 });
    setCookie(event, "csrf", "", { ...cookieOpts, httpOnly: false, maxAge: 0 });
    logger.info("[AUTH] Logout successful", { requestId, userId });
    return { ok: true };
  } catch (error) {
    logger.error("[AUTH] Logout failed", {
      requestId,
      error: (error == null ? void 0 : error.message) || "Unknown error"
    });
    throw createError({
      statusCode: 500,
      statusMessage: "Logout failed"
    });
  }
});

export { logout_post as default };
//# sourceMappingURL=logout.post.mjs.map
