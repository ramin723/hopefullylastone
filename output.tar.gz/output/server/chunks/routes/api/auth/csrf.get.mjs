import { c as defineEventHandler, i as setCookie } from '../../../_/nitro.mjs';
import crypto from 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';

const isProd = true;
const csrf_get = defineEventHandler((event) => {
  const token = crypto.randomBytes(24).toString("hex");
  setCookie(event, "csrf", token, {
    httpOnly: false,
    // باید قابل خواندن توسط JS باشد
    sameSite: "lax",
    secure: isProd,
    path: "/",
    maxAge: 60 * 60 * 24
  });
  return { csrf: token };
});

export { csrf_get as default };
//# sourceMappingURL=csrf.get.mjs.map
