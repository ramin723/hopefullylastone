import { c as defineEventHandler, l as getCookie, e as createError, i as setCookie } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { h as hashRefreshToken, g as generateAccessToken, a as generateRefreshToken, b as getRefreshTokenExpiry } from '../../../_/tokens.mjs';
import { c as createRequestLogger } from '../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const refresh_post = defineEventHandler(async (event) => {
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Token refresh attempt started");
  const refreshToken = getCookie(event, "rt");
  if (!refreshToken) {
    logger.error("Refresh failed: no refresh token in cookie");
    throw createError({ statusCode: 401, statusMessage: "No refresh token" });
  }
  const refreshTokenHash = hashRefreshToken(refreshToken);
  const dbRefreshToken = await prisma.refreshToken.findFirst({
    where: { tokenHash: refreshTokenHash },
    include: { user: true }
  });
  if (!dbRefreshToken) {
    logger.error("Refresh failed: refresh token not found in database");
    throw createError({ statusCode: 401, statusMessage: "Invalid refresh token" });
  }
  if (dbRefreshToken.revokedAt) {
    logger.error("Refresh failed: refresh token already revoked", { userId: dbRefreshToken.userId });
    throw createError({ statusCode: 401, statusMessage: "Refresh token revoked" });
  }
  if (dbRefreshToken.expiresAt < /* @__PURE__ */ new Date()) {
    logger.error("Refresh failed: refresh token expired", { userId: dbRefreshToken.userId });
    throw createError({ statusCode: 401, statusMessage: "Refresh token expired" });
  }
  await prisma.refreshToken.update({
    where: { id: dbRefreshToken.id },
    data: { revokedAt: /* @__PURE__ */ new Date() }
  });
  const newAccessToken = generateAccessToken({
    userId: dbRefreshToken.user.id,
    role: dbRefreshToken.user.role,
    phone: dbRefreshToken.user.phone
  });
  const newRefreshToken = generateRefreshToken();
  const newRefreshTokenHash = hashRefreshToken(newRefreshToken);
  const newExpiresAt = getRefreshTokenExpiry();
  await prisma.refreshToken.create({
    data: {
      userId: dbRefreshToken.user.id,
      tokenHash: newRefreshTokenHash,
      userAgent: dbRefreshToken.userAgent,
      ip: dbRefreshToken.ip,
      expiresAt: newExpiresAt
    }
  });
  const isProd = true;
  setCookie(event, "at", newAccessToken, {
    httpOnly: true,
    sameSite: "lax",
    secure: isProd,
    // ← DEV: false  |  PROD: true
    path: "/",
    maxAge: 60 * 15
    // 15m
  });
  setCookie(event, "rt", newRefreshToken, {
    httpOnly: true,
    sameSite: "lax",
    secure: isProd,
    // ← DEV: false  |  PROD: true
    path: "/",
    maxAge: 60 * 60 * 24 * 30
    // 30d
  });
  logger.info("Token refresh successful", { userId: dbRefreshToken.user.id });
  return {
    user: {
      id: dbRefreshToken.user.id,
      role: dbRefreshToken.user.role,
      fullName: dbRefreshToken.user.fullName,
      phone: dbRefreshToken.user.phone
    }
  };
});

export { refresh_post as default };
//# sourceMappingURL=refresh.post.mjs.map
