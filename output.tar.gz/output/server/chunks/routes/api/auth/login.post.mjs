import { c as defineEventHandler, r as readBody, e as createError, h as appendResponseHeader, j as getHeader, k as getRequestIP, i as setCookie } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import bcrypt from 'file://D:/hamkari/node_modules/bcryptjs/index.js';
import { g as generateAccessToken, a as generateRefreshToken, h as hashRefreshToken, b as getRefreshTokenExpiry } from '../../../_/tokens.mjs';
import { c as createRequestLogger } from '../../../_/logger.mjs';
import { randomUUID } from 'node:crypto';
import { b as buildLoginKey, r as rateLimitComposite, m as maskPhone } from '../../../_/rateLimiter.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const login_post = defineEventHandler(async (event) => {
  const requestId = randomUUID();
  const logger = createRequestLogger(requestId);
  logger.info("Login attempt started");
  const body = await readBody(event);
  if (!(body == null ? void 0 : body.phone) || !(body == null ? void 0 : body.password)) {
    logger.error("Login failed: missing phone or password");
    throw createError({ statusCode: 400, statusMessage: "phone & password required" });
  }
  const key = buildLoginKey(event, body.phone);
  const { allowed, remaining, resetAt } = rateLimitComposite({
    key,
    windowMs: 5 * 60 * 1e3,
    // 5 minutes
    max: 5
  });
  if (!allowed) {
    const retryAfterSec = Math.max(1, Math.ceil((resetAt - Date.now()) / 1e3));
    appendResponseHeader(event, "Retry-After", retryAfterSec);
    logger.warn("[AUTH] Login rate-limited", {
      requestId,
      phone: maskPhone(body.phone),
      remaining,
      resetAt
    });
    throw createError({
      statusCode: 429,
      statusMessage: "Too Many Requests",
      message: "Too many login attempts. Please try again later."
    });
  }
  logger.info("[AUTH] Login attempt allowed", {
    requestId,
    phone: maskPhone(body.phone),
    remaining,
    resetAt
  });
  const user = await prisma.user.findUnique({
    where: { phone: body.phone },
    select: {
      id: true,
      role: true,
      fullName: true,
      phone: true,
      mustChangePassword: true,
      passwordHash: true
    }
  });
  if (!user) {
    logger.error("Login failed: user not found", { phone: body.phone });
    throw createError({ statusCode: 401, statusMessage: "Invalid credentials" });
  }
  const ok = await bcrypt.compare(body.password, user.passwordHash);
  if (!ok) {
    logger.error("Login failed: wrong password", { phone: body.phone });
    throw createError({ statusCode: 401, statusMessage: "Invalid credentials" });
  }
  const accessToken = generateAccessToken({
    userId: user.id,
    role: user.role,
    phone: user.phone
  });
  const refreshToken = generateRefreshToken();
  const refreshTokenHash = hashRefreshToken(refreshToken);
  const expiresAt = getRefreshTokenExpiry();
  const userAgent = getHeader(event, "user-agent") || void 0;
  const ip = getRequestIP(event) || void 0;
  await prisma.refreshToken.create({
    data: {
      userId: user.id,
      tokenHash: refreshTokenHash,
      userAgent,
      ip,
      expiresAt
    }
  });
  const isProd = true;
  setCookie(event, "at", accessToken, {
    httpOnly: true,
    sameSite: "lax",
    secure: isProd,
    // ← DEV: false  |  PROD: true
    path: "/",
    maxAge: 60 * 15
    // 15m
  });
  setCookie(event, "rt", refreshToken, {
    httpOnly: true,
    sameSite: "lax",
    secure: isProd,
    // ← DEV: false  |  PROD: true
    path: "/",
    maxAge: 60 * 60 * 24 * 30
    // 30d
  });
  logger.info("Login successful", {
    userId: user.id,
    role: user.role,
    fullName: user.fullName
  });
  return {
    user: {
      id: user.id,
      role: user.role,
      fullName: user.fullName,
      phone: user.phone,
      mustChangePassword: user.mustChangePassword
    }
  };
});

export { login_post as default };
//# sourceMappingURL=login.post.mjs.map
