import { c as defineEventHandler, e as createError, g as getQuery } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import { d as decimalToNumber } from '../../../_/decimal.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';

const transactions_get = defineEventHandler(async (event) => {
  try {
    try {
      await prisma.$queryRaw`SELECT 1`;
    } catch (dbError) {
      console.error("[MECHANIC API] Database connection failed:", dbError);
      throw createError({
        statusCode: 500,
        statusMessage: "\u062E\u0637\u0627 \u062F\u0631 \u0627\u062A\u0635\u0627\u0644 \u0628\u0647 \u067E\u0627\u06CC\u06AF\u0627\u0647 \u062F\u0627\u062F\u0647"
      });
    }
    const auth = await requireAuth(event, ["MECHANIC"]);
    const mech = await prisma.mechanic.findUnique({ where: { userId: auth.id } });
    if (!mech) {
      throw createError({ statusCode: 403, statusMessage: "Mechanic not found" });
    }
    const query = getQuery(event);
    const { from, to, status, page = "1", pageSize = "20" } = query;
    const pageNum = parseInt(page) || 1;
    const pageSizeNum = Math.min(parseInt(pageSize) || 20, 100);
    const skip = (pageNum - 1) * pageSizeNum;
    const where = { mechanicId: mech.id };
    if (from || to) {
      where.createdAt = {};
      if (from) {
        try {
          where.createdAt.gte = new Date(from);
        } catch (dateError) {
          console.error("[MECHANIC API] Invalid from date:", from, dateError);
          throw createError({
            statusCode: 400,
            statusMessage: "\u062A\u0627\u0631\u06CC\u062E \u0634\u0631\u0648\u0639 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A"
          });
        }
      }
      if (to) {
        try {
          const toDate = new Date(to);
          toDate.setHours(23, 59, 59, 999);
          where.createdAt.lte = toDate;
        } catch (dateError) {
          console.error("[MECHANIC API] Invalid to date:", to, dateError);
          throw createError({
            statusCode: 400,
            statusMessage: "\u062A\u0627\u0631\u06CC\u062E \u067E\u0627\u06CC\u0627\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A"
          });
        }
      }
    }
    if (status && status !== "") {
      where.status = status;
    }
    const totalCount = await prisma.transaction.count({ where });
    let items;
    try {
      items = await prisma.transaction.findMany({
        where,
        orderBy: { id: "desc" },
        skip,
        take: pageSizeNum,
        include: {
          commission: true,
          vendor: { select: { id: true, user: { select: { fullName: true } } } }
        }
      });
    } catch (queryError) {
      console.error("[MECHANIC API] Database query failed:", queryError);
      throw createError({
        statusCode: 500,
        statusMessage: "\u062E\u0637\u0627 \u062F\u0631 \u062F\u0631\u06CC\u0627\u0641\u062A \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0632 \u067E\u0627\u06CC\u06AF\u0627\u0647 \u062F\u0627\u062F\u0647"
      });
    }
    const totalMechanic = items.reduce((sum, item) => {
      var _a;
      return sum + decimalToNumber((_a = item.commission) == null ? void 0 : _a.mechanicAmount);
    }, 0);
    const result = {
      items: items.map((item) => {
        var _a;
        return {
          id: item.id,
          createdAt: item.createdAt,
          vendor: item.vendor.user.fullName,
          status: item.status,
          amountTotal: decimalToNumber(item.amountTotal),
          amountEligible: decimalToNumber(item.amountEligible),
          mechanicAmount: decimalToNumber((_a = item.commission) == null ? void 0 : _a.mechanicAmount),
          customerPhone: item.customerPhone,
          note: item.note,
          mechanicCode: mech.code
        };
      }),
      count: items.length,
      totalCount,
      totalMechanic,
      page: pageNum,
      pageSize: pageSizeNum,
      hasMore: skip + items.length < totalCount
    };
    return result;
  } catch (error) {
    console.error("[MECHANIC API] Error:", error);
    if (error.statusCode) {
      throw error;
    }
    throw createError({
      statusCode: 500,
      statusMessage: "\u062E\u0637\u0627\u06CC \u062F\u0627\u062E\u0644\u06CC \u0633\u0631\u0648\u0631"
    });
  }
});

export { transactions_get as default };
//# sourceMappingURL=transactions.get.mjs.map
