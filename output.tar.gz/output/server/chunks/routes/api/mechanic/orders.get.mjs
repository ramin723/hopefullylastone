import { c as defineEventHandler, e as createError, g as getQuery } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../_/rateLimiter.mjs';
import { l as logger } from '../../../_/logger.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const orders_get = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["MECHANIC"]);
    const ip = getClientIP(event);
    const rateKey = `mechanic.orders:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 5 * 60 * 1e3,
      // 5 minutes
      max: 60
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many requests"
      });
    }
    const query = getQuery(event);
    const status = query.status;
    const search = query.search;
    const page = Math.max(1, parseInt(query.page) || 1);
    const pageSize = Math.min(100, Math.max(1, parseInt(query.pageSize) || 20));
    const skip = (page - 1) * pageSize;
    const mechanic = await prisma.mechanic.findUnique({
      where: { userId: auth.id },
      select: { id: true }
    });
    if (!mechanic) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mechanic profile not found"
      });
    }
    const where = {
      mechanicId: mechanic.id
    };
    if (status && status !== "ALL") {
      where.status = status;
    }
    if (search) {
      where.customerPhone = {
        contains: search.trim()
      };
    }
    const [orders, totalCount] = await Promise.all([
      prisma.order.findMany({
        where,
        select: {
          id: true,
          code: true,
          customerPhone: true,
          note: true,
          status: true,
          createdAt: true,
          _count: {
            select: {
              items: true
            }
          }
        },
        orderBy: { createdAt: "desc" },
        skip,
        take: pageSize
      }),
      prisma.order.count({ where })
    ]);
    const transformedOrders = orders.map((order) => ({
      id: order.id,
      code: order.code,
      customerPhone: order.customerPhone,
      note: order.note,
      status: order.status,
      createdAt: order.createdAt,
      itemCount: order._count.items
    }));
    logger.info({
      mechanicId: mechanic.id,
      userId: auth.id,
      status,
      search: search ? `***${search.slice(-4)}` : null,
      page,
      pageSize,
      resultCount: transformedOrders.length,
      totalCount
    }, "[MECHANIC ORDERS API] Orders retrieved");
    if (transformedOrders.length === 0 && totalCount > 0) {
      logger.warn({
        mechanicId: mechanic.id,
        userId: auth.id,
        where,
        totalCount,
        message: "Empty results but totalCount > 0 - possible mapping issue"
      }, "[MECHANIC ORDERS API] Empty results with non-zero total");
    }
    return {
      ok: true,
      items: transformedOrders,
      hasMore: skip + pageSize < totalCount,
      totalCount,
      page,
      pageSize
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error({ err: error }, "[MECHANIC ORDERS API] Error retrieving orders");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while retrieving orders"
    });
  }
});

export { orders_get as default };
//# sourceMappingURL=orders.get.mjs.map
