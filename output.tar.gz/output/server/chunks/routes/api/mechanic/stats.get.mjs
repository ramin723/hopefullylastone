import { c as defineEventHandler, e as createError } from '../../../_/nitro.mjs';
import { prisma } from '../../../_/db.mjs';
import { r as requireAuth } from '../../../_/auth.mjs';
import { g as getClientIP, r as rateLimitComposite } from '../../../_/rateLimiter.mjs';
import { l as logger } from '../../../_/logger.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';
import 'file://D:/hamkari/node_modules/jsonwebtoken/index.js';
import 'file://D:/hamkari/node_modules/@prisma/client/default.js';
import 'file://D:/hamkari/node_modules/pino/pino.js';

const stats_get = defineEventHandler(async (event) => {
  try {
    const auth = await requireAuth(event, ["MECHANIC"]);
    const ip = getClientIP(event);
    const rateKey = `mechanic.stats:${ip}:${auth.id}`;
    const rateLimit = rateLimitComposite({
      key: rateKey,
      windowMs: 5 * 60 * 1e3,
      // 5 minutes
      max: 100
    });
    if (!rateLimit.allowed) {
      throw createError({
        statusCode: 429,
        statusMessage: "Too many requests"
      });
    }
    const mechanic = await prisma.mechanic.findUnique({
      where: { userId: auth.id },
      select: { id: true }
    });
    if (!mechanic) {
      throw createError({
        statusCode: 404,
        statusMessage: "Mechanic not found"
      });
    }
    const [totalTransactions, totalOrdersResult, totalEarnings] = await Promise.all([
      // Total transactions
      prisma.transaction.count({
        where: { mechanicId: mechanic.id }
      }),
      // Total orders - with fallback for P2021 (table not found)
      (async () => {
        try {
          return await prisma.order.count({
            where: { mechanicId: mechanic.id }
          });
        } catch (err) {
          if (err.code === "P2021" || err.name === "PrismaClientKnownRequestError") {
            logger.warn("[MECHANIC STATS API] Order table not found, using fallback value");
            return 0;
          }
          throw err;
        }
      })(),
      // Total earnings (sum of mechanic amounts from commissions)
      prisma.commission.aggregate({
        where: {
          transaction: { mechanicId: mechanic.id }
        },
        _sum: { mechanicAmount: true }
      })
    ]);
    const totalOrders = totalOrdersResult;
    logger.info({
      mechanicId: mechanic.id,
      userId: auth.id
    }, "[MECHANIC STATS API] Stats retrieved");
    return {
      ok: true,
      totalTransactions,
      totalOrders,
      totalEarnings: totalEarnings._sum.mechanicAmount || 0
    };
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    logger.error({ err: error }, "[MECHANIC STATS API] Error retrieving stats");
    throw createError({
      statusCode: 500,
      statusMessage: "Internal server error while retrieving stats"
    });
  }
});

export { stats_get as default };
//# sourceMappingURL=stats.get.mjs.map
